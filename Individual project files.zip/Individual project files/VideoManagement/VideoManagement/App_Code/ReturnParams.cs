﻿using System.Text;
public class ReturnParams
{   
    public string messageTitle { get; set; }
    public string message { get; set; }
    public string responseCode { get; set; }
    public string langID { get; set; }
}
