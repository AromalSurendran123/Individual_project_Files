public class RequestObj
{
    public string Item0 { get; set; }
    public string Item1 { get; set; }
    public string Item2 { get; set; }
    public string Item3 { get; set; }
    public string Item4 { get; set; }
    public string Item5 { get; set; }
    public string Item6 { get; set; }
    public string Item7 { get; set; }
    public string Item8 { get; set; }
    public string Item9 { get; set; }
    public string Item10 { get; set; }
    public string Item11 { get; set; }
    public string Item12 { get; set; }
    public string Item13 { get; set; }
    public string Item14 { get; set; }
    public string Item15 { get; set; }
    public string Item16 { get; set; }
    public string Item17 { get; set; }
    public string Item18 { get; set; }
    public string Item19 { get; set; }
    public string Item20 { get; set; }
    //for lazy loadding
    public int l_Limit { get; set; }
    public int u_Limit { get; set; }
    public int rowCount { get; set; }
}
