﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;


public class videos
{
    public string Id { get; set; }
    public string Downloadable { get; set; }
    public string Title { get; set; }
    public string FileName { get; set; }
    public string CountPointer { get; set; }
    public string NextBtn { get; set; }
    public string PreviousBtn { get; set; }
    public string TotalCount { get; set; }
    public string AllowEdit{ get; set; }
    
}