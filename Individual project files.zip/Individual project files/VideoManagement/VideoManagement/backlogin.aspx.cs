﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace VideoManagement
{
    public partial class backlogin : System.Web.UI.Page
    {
        private DBI db = new DBI();
        protected User User = new User();
       
        protected void Page_Load(object sender, EventArgs e)
        {           
            if (!Page.IsPostBack)
            {
                Session["PAGE_LOAD"] = null;
                ScriptManager.RegisterStartupScript(this, this.GetType(), "LAW", "javascript:ClearLoginFields();", true);
            } 
        }

        public bool ValidateUser(string _email, string _pwd)
        {

            MySqlDataReader dr = null;
            bool flag = false;
            string sql = "";

            try
            {
                sql = "SELECT  fld_id," +
                    "fld_firstname,"+
                    "fld_lastname," +
                    "fld_email "+
                    "FROM tbl_users " +
                    "WHERE fld_email= @email " +
                    "AND fld_password = @password " +
                    "AND fld_status = '1'";
                MySqlCommand cmd = new MySqlCommand(sql);
                cmd.Parameters.AddWithValue("@email", _email);
                cmd.Parameters.AddWithValue("@password", _pwd);
                dr = db.Read(cmd);

                if (dr.Read())
                {
                    flag = true;
                    User.UserId = dr["fld_id"].ToString();
                    User.FirstName = dr["fld_firstname"].ToString();
                    User.LastName = dr["fld_lastname"].ToString();
                    User.Email = dr["fld_email"].ToString();     
                }
                dr.Close();
                if (flag == true)
                {
                    System.Web.HttpContext.Current.Session["VdoUser"] = User;                   
                    System.Web.Security.FormsAuthentication.SetAuthCookie(User.UserId, false);                    
                }
            }
            finally
            {
                db.Close();
            }
            return flag;
        }

        protected void btn_login_Click(object sender, EventArgs e)
        {

            if (txt_User.Text != "" && txt_Password.Text != "")
            {
                string usr = txt_User.Text;
                string pwd = txt_Password.Text;

                Session["AirAdmin"] = null;

                if (ValidateUser(usr, pwd) == true)
                {
                    Response.Cookies["jesarAdmin"].Value = usr;
                    Response.Cookies["jesarAdmin"].Value = pwd;
                    Response.Redirect("airships.aspx", true);
                }

                else
                {
                    string msg = "Invalid Login";
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "BQW", "javascript:InfoPopup('','" + msg + "','1');", true);
                    txt_Password.Attributes.Add("value", "********");                    
                }
            }
            else
            {
                string msg = "Please enter valid data";
                ScriptManager.RegisterStartupScript(this, this.GetType(), "BQW", "javascript:InfoPopup('','" + msg + "','1');", true);
                txt_Password.Attributes.Add("value", "********");
            }
        }
    }
}