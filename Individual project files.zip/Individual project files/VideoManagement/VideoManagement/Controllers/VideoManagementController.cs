﻿using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace VideoManagement.Controllers
{
    public class VideoManagementController : ApiController
    {
        VideoManagementDataLayer DLayer = new VideoManagementDataLayer();

        #region SAVE VIDEO
        [HttpPost]
        public HttpResponseMessage DeleteVideo(RequestObj reqObj)
        {
            ResponseObj resObj = new ResponseObj();
            resObj = DLayer.DeleteVideo(reqObj);
            return Request.CreateResponse(HttpStatusCode.OK, resObj);
        }
        [HttpPost]
        public HttpResponseMessage LoadVideoDetails(RequestObj reqObj)
        {
            ResponseObj resObj = new ResponseObj();
            resObj = DLayer.LoadVideoDetails(reqObj);
            return Request.CreateResponse(HttpStatusCode.OK, resObj);
        }
        [HttpPost]
        public HttpResponseMessage SaveVideo()
        {
            ResponseObj resObj = new ResponseObj();
            resObj = DLayer.SaveVideo();
            return Request.CreateResponse(HttpStatusCode.OK, resObj);
        }
        [HttpPost]
        public HttpResponseMessage LoadUsers(RequestObj reqObj)
        {
            ResponseObj resObj = new ResponseObj();
            resObj = DLayer.LoadUsers(reqObj);
            return Request.CreateResponse(HttpStatusCode.OK, resObj);
        }
        #endregion

        #region VIDEO LIST
        [HttpPost]
        public List<videos> LoadVideos(RequestObj reqObj)
        {
            List<videos> Videos = DLayer.LoadVideos(reqObj);
            return Videos;
        }
        #endregion

        #region SIGNIN
        [HttpPost]
        public HttpResponseMessage SubmitSigIn(RequestObj reqObj)
        {
            ResponseObj resObj = new ResponseObj();
            resObj = DLayer.SubmitSigIn(reqObj);
            return Request.CreateResponse(HttpStatusCode.OK, resObj);
        }
        #endregion
    }
}
