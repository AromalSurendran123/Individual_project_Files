﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace VideoManagement.controls
{
    public partial class head : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            User usr = new User();
            if (Session["VDOUSR"] != null)
            {
                if (Session["VDOUSR"].ToString() != "")
                {
                    usr = (User)Session["VDOUSR"];
                    ltrl_LoginLogOut.Text = "<a class=\"button button_signin\" alt=\"Sign Out\" title=\"Sign Out\" href=\"logout\"><ul class=\"w3-ul\"><li class=\"w3-large\"><i class=\"fa fa-sign-out\"></i>" + usr.FirstName + " " + usr.LastName + "</li></ul></a>";                    
                }
                else
                {
                    ltrl_LoginLogOut.Text = "<a class=\"button button_signin\" onclick=\"ShowLoginModal();\"><ul class=\"w3-ul\"><li class=\"w3-large\"><i class=\"material-icons w3-large\">person</i>SIGN IN</li></ul></a>";
                    ltrl_register_user.Text = "<a class=\"button button_signin\" onclick=\"ShowRegisterModal();\"><ul class=\"w3-ul\"><li class=\"w3-large\"><i class=\"material-icons w3-large\">person</i>REGISTER</li></ul></a>";
                     
                }
            }
            else
            {
                ltrl_LoginLogOut.Text = "<a class=\"button button_signin\" onclick=\"ShowLoginModal();\"><ul class=\"w3-ul\"><li class=\"w3-large\"><i class=\"material-icons w3-large\">person</i>SIGN IN</li></ul></a>";
                ltrl_register_user.Text = "<a class=\"button button_signin\" onclick=\"ShowRegisterModal();\"><ul class=\"w3-ul\"><li class=\"w3-large\"><i class=\"material-icons w3-large\">person</i>REGISTER</li></ul></a>";
            }


        }
    }
}