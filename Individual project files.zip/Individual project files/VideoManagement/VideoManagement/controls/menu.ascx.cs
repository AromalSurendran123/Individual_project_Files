﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace VideoManagement.controls
{
    public partial class menu : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        public string GetLoggedName()
        {
            string Name = string.Empty;
            if (System.Web.HttpContext.Current.Session["CRAPSEEADMIN"] != null)
            {
                User usr = (User)Session["CRAPSEEADMIN"];
                Name = usr.FirstName + " " + usr.LastName;
            }
            return Name;
        }
    }
}