﻿using MySql.Data.MySqlClient;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;
using System.Linq;
using System.Security.Cryptography;

public class VideoManagementDataLayer
{
    protected DBI db = new DBI();
    protected DBI db2 = new DBI();
    MySqlDataReader dr = null;
    MySqlDataReader dr2 = null;
    MySqlCommand cmd = null;
    MySqlCommand cmd2 = null;
    string sql = string.Empty;
    string sql2 = string.Empty;
    string key = "b14ca5898a4e4133bbce2ea2315a1916"; 

    string CombinedTitle = string.Empty;
    public VideoManagementDataLayer()
    {
        //
        // TODO: Add constructor logic here
        //
    }
    ~VideoManagementDataLayer()
    {

    }

    #region SAVE VIDEO

    public ResponseObj DeleteVideo(RequestObj reqObj)
    {
        if (System.Web.HttpContext.Current.Session["VDOUSR"] == null)
        {
            return myMessage("0", "Session expired", "Please login again.");
        }
        int ivalue = 0;
        if (!int.TryParse(reqObj.Item0.Trim(), out ivalue))
        {
            return myMessage("0", "Warning", "Invalid operation.");
        }
        ResponseObj resObj = new ResponseObj();

        User usr = new User();
        usr = (User)System.Web.HttpContext.Current.Session["VDOUSR"];
        try
        {
            string FileName = string.Empty;
            string AccessType = string.Empty;

            sql = "SELECT fld_Id," +               
                "fld_FileName," +
                "fld_AccessType " +
                "FROM tbl_videos " +
                "WHERE fld_Id = @Id " +
                "AND fld_AddedBy = @AddedBy " +
                "AND fld_Status = 1";
            cmd = new MySqlCommand(sql);
            cmd.Parameters.AddWithValue("@Id", reqObj.Item0.Trim());
            cmd.Parameters.AddWithValue("@AddedBy", usr.UserId);
            dr = db.Read(cmd);
            if (dr.Read())
            {
                if (dr["fld_Id"].ToString() != "")
                {
                    FileName = dr["fld_FileName"].ToString(); 
                    AccessType = dr["fld_AccessType"].ToString();                   
                }
            }
            dr.Close();
            cmd.Connection.Close();
            cmd.Dispose();

            FileName = HttpContext.Current.Server.MapPath("~/videos/" + FileName);
            if (File.Exists(FileName))
            {
                File.Delete(FileName);
            }

            if (AccessType == "0")
            {
                sql = "UPDATE tbl_video_access SET " +
                        "fld_status = 0 " +
                        "WHERE fld_VideoId = @VideoId";
                cmd = new MySqlCommand(sql);
                cmd.Parameters.AddWithValue("@VideoId", reqObj.Item0.Trim());
                db.Execute(cmd);
                cmd.Connection.Close();
                cmd.Dispose();
            }

            sql = "UPDATE tbl_videos SET "+
                "fld_status = 0 "+
                "WHERE fld_Id = @Id " +
                "AND fld_AddedBy = @AddedBy " +
                "AND fld_Status = 1";
            cmd = new MySqlCommand(sql);
            cmd.Parameters.AddWithValue("@Id", reqObj.Item0.Trim());
            cmd.Parameters.AddWithValue("@AddedBy", usr.UserId);
            db.Execute(cmd);
            cmd.Connection.Close();
            cmd.Dispose();          
        }
        catch (Exception err)
        {
            throw err;
        }
        finally
        {
            db.Close();
        }

        resObj.rcode = "1";
        resObj.rtitle = "Success";
        resObj.rmsg = "Video has been deleted successfully.";
        return resObj;
    }

    public ResponseObj LoadVideoDetails(RequestObj reqObj)
    {
        if (System.Web.HttpContext.Current.Session["VDOUSR"] == null)
        {            
            return myMessage("0", "Session expired", "Please login again.");
        }
        int ivalue = 0;
        if (!int.TryParse(reqObj.Item0.Trim(), out ivalue))
        {
            return myMessage("0", "Warning", "Invalid operation.");
        }
        ResponseObj resObj = new ResponseObj();

        User usr = new User();
        usr = (User)System.Web.HttpContext.Current.Session["VDOUSR"];
        try
        {
            
            sql = "SELECT fld_Id," +
                "fld_Title," +
                "fld_FileName," +
                "fld_AccessType," +
                "fld_Downloadable " +
                "FROM tbl_videos " +
                "WHERE fld_Id = @Id " +
                "AND fld_AddedBy = @AddedBy " +
                "AND fld_Status = 1";
            cmd = new MySqlCommand(sql);
            cmd.Parameters.AddWithValue("@Id", reqObj.Item0.Trim());
            cmd.Parameters.AddWithValue("@AddedBy", usr.UserId);
            dr = db.Read(cmd);
            if (dr.Read())
            {
                if (dr["fld_Id"].ToString() != "")
                {
                    resObj.Item0 = dr["fld_Id"].ToString();                    
                    resObj.Item1 = dr["fld_Title"].ToString();                    
                    resObj.Item3 = dr["fld_AccessType"].ToString();
                    resObj.Item4 = dr["fld_Downloadable"].ToString();
                }
            }
            dr.Close();
            cmd.Connection.Close();
            cmd.Dispose();

        }
        catch (Exception err)
        {
            throw err;
        }
        finally
        {
            db.Close();
        }

        resObj.rcode = "1";
        return resObj;
    }

    private string GetExtension(string FileName)
    {
        string[] split = FileName.Split('.');
        string Extension = split[split.Length - 1];
        return Extension;
    }

    public ResponseObj SaveVideo()
    {
        ResponseObj resObj = new ResponseObj();
        if (System.Web.HttpContext.Current.Session["VDOUSR"] == null)
        {
            return myMessage("0", "Session expired", "Please login again.");
        }
            User usr = new User();            
            usr = (User)System.Web.HttpContext.Current.Session["VDOUSR"];
            string VideoId = HttpContext.Current.Request["VideoId"].ToString();
            string Title = HttpContext.Current.Request["Title"].ToString();
            string Downlodable = HttpContext.Current.Request["Downlodable"].ToString();
            string Accessibility = HttpContext.Current.Request["Accessibility"].ToString();
            string UserIds = HttpContext.Current.Request["UserIds"].ToString();
            int ivalue = 0;
            if (VideoId != "")
            {
                if (!int.TryParse(VideoId, out ivalue))
                {
                    return myMessage("0", "Warning", "Invalid operation.");
                }
                else
                {
                    if (HttpContext.Current.Request.Files.Count > 0)
                    {
                        return myMessage("0", "Warning", "Please select one video file.");
                    }
                }
            }
            if (string.IsNullOrEmpty(Title))
            {
                return myMessage("0", "Warning", "Title is required.");
            }
            if (string.IsNullOrEmpty(Downlodable))
            {
                return myMessage("0", "Warning", "Downlodable is required.");
            }
            else
            {
                if (Downlodable == "00")
                {
                    return myMessage("0", "Warning", "Downlodable is required.");
                }
            }
            if (string.IsNullOrEmpty(Accessibility))
            {
                return myMessage("0", "Warning", "Accessibility is required.");
            }
            else
            {
                if (Downlodable == "00")
                {
                    return myMessage("0", "Warning", "Accessibility is required.");
                }
            }
            if (Accessibility != "0")
            {
                UserIds = string.Empty;
            }  
            
            try
            {
                if (VideoId.Trim() == "")//ADD VIDEOS
                {                    
                    sql = "INSERT INTO tbl_videos(" +
                        "fld_Order," +
                        "fld_Title," +
                        "fld_Downloadable," +
                        "fld_AccessType," +
                        "fld_AddedBy," +
                        "fld_DateAdded," +
                        "fld_DateModified," +
                        "fld_Status) VALUES(" +
                        "@Order," +
                        "@Title," +
                        "@Downloadable," +
                        "@Accessibility," +
                        "@AddedBy," +
                        "NOW()," +
                        "NOW()," +
                        "@Status);"+
                        "UPDATE tbl_videos SET " +
                        "fld_order = fld_order+1 " +
                        "WHERE fld_status = @Status;" +
                        "SELECT MAX(fld_id) AS fld_id " +
                        "FROM tbl_videos "+
                        "WHERE fld_status = @Status "+
                        "AND fld_AddedBy = @AddedBy";
                    cmd = new MySqlCommand(sql);
                    cmd.Parameters.AddWithValue("@Order", "0");
                    cmd.Parameters.AddWithValue("@Title", Title);
                    cmd.Parameters.AddWithValue("@Downloadable", Downlodable);
                    cmd.Parameters.AddWithValue("@Accessibility", Accessibility);
                    cmd.Parameters.AddWithValue("@AddedBy", usr.UserId);
                    cmd.Parameters.AddWithValue("@Status", "1");                    
                    dr = db.Read(cmd);
                    if (dr.Read())
                    {
                        if (dr["fld_id"].ToString() != "")
                        {
                            VideoId = dr["fld_id"].ToString();
                        }
                    }
                    dr.Close();
                    cmd.Connection.Close();
                    cmd.Dispose();       
                    resObj.rmsg = "Video added successfully!";
                }
                else//UPDATE VIDEOS
                {
                    sql = "UPDATE tbl_video_access SET " +
                        "fld_status = 0 " +
                        "WHERE fld_VideoId = @VideoId";
                    cmd = new MySqlCommand(sql);
                    cmd.Parameters.AddWithValue("@VideoId", VideoId);
                    db.Execute(cmd);
                    cmd.Connection.Close();
                    cmd.Dispose();

                    sql = "UPDATE tbl_videos SET " +
                        "fld_Title = @Title," +
                        "fld_Downloadable = @Downloadable," +
                        "fld_AccessType = @AccessType," +
                        "fld_DateModified = NOW() " +
                        "WHERE fld_id = @Id";
                    cmd = new MySqlCommand(sql);
                    cmd.Parameters.AddWithValue("@Id", VideoId);
                    cmd.Parameters.AddWithValue("@Title", Title);
                    cmd.Parameters.AddWithValue("@Downloadable", Downlodable);
                    cmd.Parameters.AddWithValue("@AccessType", Accessibility);
                    db.Execute(cmd);
                    cmd.Connection.Close();
                    cmd.Dispose();
                    resObj.rmsg = "Video updated successfully!";
                }

                if (Accessibility == "0")
                {                    
                    if (!string.IsNullOrEmpty(UserIds))
                    {
                        UserIds = UserIds + "," + usr.UserId;
                    }
                    else
                    {
                        UserIds = usr.UserId;
                    }
                    string[] UsrArry = UserIds.Split(',');
                    foreach (string str in UsrArry)
                    {
                        sql = "INSERT INTO tbl_video_access(" +
                        "fld_UserId," +
                        "fld_VideoId," +
                        "fld_Status) VALUES(" +
                        "@UserId," +
                        "@VideoId," +
                        "@Status)";
                        cmd = new MySqlCommand(sql);
                        cmd.Parameters.AddWithValue("@UserId", str);
                        cmd.Parameters.AddWithValue("@VideoId", VideoId);
                        cmd.Parameters.AddWithValue("@Status", "1");
                        db.Execute(cmd);
                        cmd.Connection.Close();
                        cmd.Dispose();
                    }

                }

                if (HttpContext.Current.Request.Files.Count > 0 && !string.IsNullOrEmpty(VideoId))
                {
                    string flocation = string.Empty;
                    string fname = string.Empty;
                    string encrypt_name = string.Empty;
                    string extn = string.Empty;
                    HttpFileCollection files = HttpContext.Current.Request.Files;

                    for (int i = 0; i < files.Count; i++)
                    {
                        HttpPostedFile file = files[i];
                        // Checking for Internet Explorer  
                        if (HttpContext.Current.Request.Browser.Browser.ToUpper() == "IE" || HttpContext.Current.Request.Browser.Browser.ToUpper() == "INTERNETEXPLORER")
                        {
                            string[] testfiles = file.FileName.Split(new char[] { '\\' });
                            fname = testfiles[testfiles.Length - 1];
                            encrypt_name =testfiles[testfiles.Length - 1];
                        }
                        else
                        {
                            fname = file.FileName;
                            encrypt_name = file.FileName;
                        }
                        if (!string.IsNullOrEmpty(fname))
                        {
                            string fileExtension = GetExtension(fname);
                            string guid = Guid.NewGuid().ToString();                            

                            fname = VideoId + "_" + guid + "." + fileExtension;
                            encrypt_name = VideoId + "_" + guid + "_enc" + "." + fileExtension;

                            flocation = Path.Combine(HttpContext.Current.Server.MapPath("~/videos/"), fname);
                           

                            string input = HttpContext.Current.Server.MapPath("~/videos/") + VideoId + "_" + guid + "." + fileExtension;
                            string output = HttpContext.Current.Server.MapPath("~/videos/") + VideoId + "_" + guid + "_enc" + "." + fileExtension;
                            //fin.Delete();

                            // Get the complete folder path and store the file inside it.
                            // Get video extension and save the content.
                            string ImgPath = HttpContext.Current.Server.MapPath("~/videos/");
                            DirectoryInfo DirPath = new DirectoryInfo(ImgPath);
                            foreach (FileInfo fin in DirPath.GetFiles(VideoId + "_*.*"))
                            {
                                if (fin.Exists)
                                {
                                    fin.Delete();
                                }
                            }                           
                            
                            file.SaveAs(flocation);
                            this.Encrypt(input, output);

                            sql = "UPDATE tbl_videos SET " +
                                    "fld_FileName = @FileName " +                              
                                    "WHERE fld_id = @Id";
                                    cmd = new MySqlCommand(sql);
                                    cmd.Parameters.AddWithValue("@Id", VideoId);
                                    cmd.Parameters.AddWithValue("@FileName", encrypt_name);
                                    db.Execute(cmd);
                                    cmd.Connection.Close();
                                    cmd.Dispose();                               
                        }
                        break;
                    }
                }
            }
            catch (Exception err)
            {
                throw err;
            }
            finally
            {
                db.Close();
            }
        
        resObj.rtitle = "Success";
        resObj.rcode = "1";
        return resObj;
    }


    //ENCRYPT VIDEO
    private void Encrypt(string inputFilePath, string outputfilePath)
    {
        string EncryptionKey = "MAKV2SPBNI99212";
        using (Aes encryptor = Aes.Create())
        {
            Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
            encryptor.Key = pdb.GetBytes(32);
            encryptor.IV = pdb.GetBytes(16);
            using (FileStream fsOutput = new FileStream(outputfilePath, FileMode.Create))
            {
                using (CryptoStream cs = new CryptoStream(fsOutput, encryptor.CreateEncryptor(), CryptoStreamMode.Write))
                {
                    using (FileStream fsInput = new FileStream(inputFilePath, FileMode.Open))
                    {
                        int data;
                        while ((data = fsInput.ReadByte()) != -1)
                        {
                            cs.WriteByte((byte)data);
                        }
                    }
                }
            }
        }
    }


    //DECRYPT VIDEO
    private void Decrypt(string inputFilePath, string outputfilePath)
    {
        string EncryptionKey = "MAKV2SPBNI99212";
        using (Aes encryptor = Aes.Create())
        {
            Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
            encryptor.Key = pdb.GetBytes(32);
            encryptor.IV = pdb.GetBytes(16);
            using (FileStream fsInput = new FileStream(inputFilePath, FileMode.Open))
            {
                using (CryptoStream cs = new CryptoStream(fsInput, encryptor.CreateDecryptor(), CryptoStreamMode.Read))
                {
                    using (FileStream fsOutput = new FileStream(outputfilePath, FileMode.Create))
                    {
                        int data;
                        while ((data = cs.ReadByte()) != -1)
                        {
                            fsOutput.WriteByte((byte)data);
                        }
                    }
                }
            }
        }
    }  

    public ResponseObj LoadUsers(RequestObj reqObj)
    {
        User usr = new User();
        bool flag = false;
        ResponseObj resObj = new ResponseObj();
        StringBuilder sbmulti = new StringBuilder();
        StringBuilder sboptions = new StringBuilder();
        StringBuilder sbcheck = new StringBuilder();
        if (System.Web.HttpContext.Current.Session["VDOUSR"] == null)
        {
            return myMessage("0", "Session expired", "Please login again.");
        }

        usr = (User)System.Web.HttpContext.Current.Session["VDOUSR"];
        try
        {
           
            sql = "SELECT fld_Id," +
                "CONCAT(fld_FirstName,' ',fld_LastName) AS Name " +
                "FROM tbl_users " +
                "WHERE fld_Id <> @Id " +
                "AND fld_Status = 1 " +
                "ORDER BY fld_FirstName";
            cmd = new MySqlCommand(sql);
            cmd.Parameters.AddWithValue("@Id", usr.UserId);
            dr = db.Read(cmd);
            while (dr.Read())
            {
                flag = true;
                sboptions.Append("<option value=\"" + dr["fld_Id"].ToString() + "\">" + dr["Name"].ToString() + "</option>");
                sbcheck.Append("<li><a tabindex=\"0\"><label class=\"checkbox\"><input name=\"chk_User\" type=\"checkbox\" value=\"" + dr["fld_Id"].ToString() + "\">" + dr["Name"].ToString() + "</label></a></li>");
            }
            dr.Close();
            cmd.Connection.Close();
            cmd.Dispose();

            string UserAccessibilityIds = string.Empty;
            if (reqObj.Item0.Trim() != "")
            {
                int i = 0;
                sql = "SELECT uva.fld_UserId AS UserId " +
                    "FROM tbl_video_access uva, tbl_users u " +
                    "WHERE uva.fld_UserId = u.fld_Id " +
                    "AND uva.fld_VideoId = @VideoId " +
                    "AND uva.fld_Status = 1 "+
                    "AND u.fld_status  = 1";
                cmd = new MySqlCommand(sql);
                cmd.Parameters.AddWithValue("@VideoId", reqObj.Item0.Trim());
                dr = db.Read(cmd);
                while (dr.Read())
                {
                    if (dr["UserId"].ToString() != "")
                    {
                        if (i == 0)
                            UserAccessibilityIds = dr["UserId"].ToString();
                        else
                            UserAccessibilityIds += "," + dr["UserId"].ToString();
                    }
                    i++;
                }
                dr.Close();
                cmd.Connection.Close();
                cmd.Dispose();
            }
            resObj.Item1 = UserAccessibilityIds;
        }
        catch (Exception err)
        {
            throw err;
        }
        finally
        {
            db.Close();
        }
        sbmulti.Append("<span class=\"multiselect-native-select\">")
        .Append("<select name=\"ddl_Users\" multiple=\"multiple\" id=\"ddl_Users\" class=\"multiselect-ui form-control\">")
            .Append(sboptions)
        .Append("</select>")
            .Append("<ul class=\"multiselect-container dropdown-menu\">")
                .Append("<li class=\"multiselect-item multiselect-filter\">")
                    .Append("<div class=\"input-group\"><span class=\"input-group-addon\"><i class=\"glyphicon glyphicon-search\"></i></span>")
                        .Append("<input class=\"form-control multiselect-search\" type=\"text\" placeholder=\"Search\"><span class=\"input-group-btn\">")
                            .Append("<button class=\"btn btn-default multiselect-clear-filter\" type=\"button\"><i class=\"glyphicon glyphicon-remove-circle\"></i></button>")
                        .Append("</span></div>")
                .Append("</li>")
                .Append("<li class=\"multiselect-item multiselect-all\"><a tabindex=\"0\" class=\"multiselect-all\">")
                    .Append("<label class=\"checkbox\">")
                        .Append("<input type=\"checkbox\" value=\"multiselect-all\">")
                        .Append("Select all</label></a></li>")
                .Append(sbcheck)
            .Append("</ul>")
    .Append("</span>");

        if (flag)
        {
            resObj.rcode = "1";
            resObj.Item0 = sbmulti.ToString();
        }
        else
        {
            resObj.Item0 = "";
        }
        return resObj;
    }
    #endregion

    #region VIDEO LIST
    public List<videos> LoadVideos(RequestObj reqObj)
    {
        
        string UserId = string.Empty;        
        string Condition = string.Empty;
        string SqlUserCondition = string.Empty;
        string VideoIds = string.Empty;        
        if (System.Web.HttpContext.Current.Session["VDOUSR"] != null)
        {
            User usr = new User();
            usr = (User)System.Web.HttpContext.Current.Session["VDOUSR"];
            UserId = usr.UserId;   
            int i = 0;

            sql = "SELECT fld_VideoId " +
                "FROM tbl_video_access " +
                "WHERE fld_UserId = @UserId " +
                "AND fld_status = 1";
            cmd = new MySqlCommand(sql);
            cmd.Parameters.AddWithValue("@UserId", usr.UserId);
            dr = db.Read(cmd);
            while(dr.Read())
            {
                if (dr["fld_VideoId"].ToString() != "")
                {
                    if(i == 0)
                        VideoIds = dr["fld_VideoId"].ToString();
                    else
                        VideoIds += "," + dr["fld_VideoId"].ToString();
                    i++;
                }
            }
            dr.Close();

            if (!string.IsNullOrEmpty(VideoIds))
            {
                SqlUserCondition = "OR (fld_Id IN (" + VideoIds + ") #SEARCH#)";
            }
        }

        int TotalRecordCount = 0;
        int ShowCount = 0;
        int CountPointer = 0;
        string Next = "0";
        string Previous = "0";
        int LowerLimit = 0;
        int UpperLimit = 0;
        List<videos> items = new List<videos>();
        int ivalue = 0;
        if (!int.TryParse(reqObj.Item0.Trim(), out ivalue))//Page Count
        {
            return items;
        }
        else
        {
            ShowCount = int.Parse(reqObj.Item0.Trim());
        }
        ivalue = 0;
        if (!int.TryParse(reqObj.Item1.Trim(), out ivalue))//Current Pointer
        {
            return items;
        }
        else
        {
            CountPointer = int.Parse(reqObj.Item1.Trim());
        }
        if (reqObj.Item2.Trim() != "")
        {
            ivalue = 0;
            if (!int.TryParse(reqObj.Item2.Trim(), out ivalue))
            {
                return items;
            }
        }
        if (reqObj.Item3.Trim() != "")
        {
            Condition = "AND fld_title LIKE CONCAT('%',@SearchText,'%') ";
            
        }
        SqlUserCondition = SqlUserCondition.Replace("#SEARCH#", Condition);
        try
        {
            sql = "SELECT COUNT(fld_id) AS TotalCount " +
                "FROM tbl_videos " +
                "WHERE fld_status = 1 " +
                "" + Condition + " " +
                "AND fld_accesstype = 1 " + SqlUserCondition;
            cmd = new MySqlCommand(sql);
            if (reqObj.Item3.Trim() != "")
            {
                cmd.Parameters.AddWithValue("@SearchText", reqObj.Item3.Trim());
            }
            dr = db.Read(cmd);
            if (dr.Read())
            {
                if (dr["TotalCount"].ToString() != "")
                {
                    TotalRecordCount = int.Parse(dr["TotalCount"].ToString());
                }
            }
            dr.Close();
            if (TotalRecordCount > 0 && TotalRecordCount >= CountPointer)
            {
                if (reqObj.Item2.Trim() != "")
                {
                    switch (reqObj.Item2.Trim())
                    {
                        case "1"://Next
                            LowerLimit = CountPointer;
                            UpperLimit = ShowCount;
                            break;
                        case "0"://Previous
                            CountPointer = CountPointer - (ShowCount * 2);
                            if (CountPointer < 0)
                                CountPointer = 0;
                            LowerLimit = CountPointer;
                            UpperLimit = ShowCount;
                            break;
                    }
                }
                else
                {
                    LowerLimit = CountPointer;
                    UpperLimit = ShowCount;
                }
                Next = "1";
                string AllowEdit = string.Empty;

                string encryped_file_name = string.Empty;
                string decrypted_file_name = string.Empty;
                string video_id = string.Empty;

                sql = "SELECT fld_id," +
                    "fld_title," +
                    "fld_filename," +
                    "fld_Downloadable," +
                    "fld_AddedBy "+
                    "FROM tbl_videos " +
                    "WHERE fld_status = 1 " +
                    "" + Condition + " " +
                    "AND fld_accesstype = 1 " +
                    ""+SqlUserCondition+ ""+
                    "ORDER BY fld_order LIMIT " + LowerLimit + " ," + UpperLimit + "";
                cmd = new MySqlCommand(sql);
                if (reqObj.Item3.Trim() != "")
                {
                    cmd.Parameters.AddWithValue("@SearchText", reqObj.Item3.Trim());
                }
                dr = db.Read(cmd);
                items.Clear();
                while (dr.Read())
                {
                    AllowEdit = string.Empty;


                    video_id = dr["fld_Id"].ToString();                    
                    encryped_file_name = dr["fld_FileName"].ToString();
                    decrypted_file_name = video_id+"_decry"+ encryped_file_name.Remove(0, video_id.Length);

                    //VIDEO DECRYPT
                    string input = HttpContext.Current.Server.MapPath("~/videos/") + encryped_file_name;
                    string output = HttpContext.Current.Server.MapPath("~/videos/") + decrypted_file_name;
                    this.Decrypt(input, output);


                    if (!string.IsNullOrEmpty(UserId))
                    {
                        if (UserId == dr["fld_AddedBy"].ToString())
                        {
                            AllowEdit = "1";
                        }
                    }  
                    if (TotalRecordCount == (CountPointer + 1))
                    {
                        Next = "0";
                    }
                    if (CountPointer >= ShowCount)
                    {
                        Previous = "1";
                    }
                    items.Add(new videos
                    {
                        Id = dr["fld_id"].ToString(),
                        Title = dr["fld_title"].ToString(),
                        //FileName = dr["fld_filename"].ToString(),
                        FileName = decrypted_file_name,
                        Downloadable = dr["fld_Downloadable"].ToString(),
                        CountPointer = (CountPointer + 1).ToString(),
                        TotalCount = TotalRecordCount.ToString(),
                        NextBtn = Next,
                        PreviousBtn = Previous,
                        AllowEdit = AllowEdit
                    });
                    CountPointer++;
                }
                dr.Close();
                cmd.Connection.Close();
                cmd.Dispose();
            }
        }
        catch (Exception err)
        {
            throw err;
        }
        finally
        {
            db.Close();
        }
        return items;
    }
    #endregion

    #region SIGNIN

    //ENCRYPT
    public static string EncryptString(string key, string plainText)
    {
        byte[] iv = new byte[16];
        byte[] array;

        using (Aes aes = Aes.Create())
        {
            aes.Key = Encoding.UTF8.GetBytes(key);
            aes.IV = iv;
            ICryptoTransform encryptor = aes.CreateEncryptor(aes.Key, aes.IV);
            using (MemoryStream memoryStream = new MemoryStream())
            {
                using (CryptoStream cryptoStream = new CryptoStream((Stream)memoryStream, encryptor, CryptoStreamMode.Write))
                {
                    using (StreamWriter streamWriter = new StreamWriter((Stream)cryptoStream))
                    {
                        streamWriter.Write(plainText);
                    }
                    array = memoryStream.ToArray();
                }
            }
        }
        return Convert.ToBase64String(array);
    }

    //DECRYPT
    public static string DecryptString(string key, string cipherText)
    {
        byte[] iv = new byte[16];
        byte[] buffer = Convert.FromBase64String(cipherText);

        using (Aes aes = Aes.Create())
        {
            aes.Key = Encoding.UTF8.GetBytes(key);
            aes.IV = iv;
            ICryptoTransform decryptor = aes.CreateDecryptor(aes.Key, aes.IV);

            using (MemoryStream memoryStream = new MemoryStream(buffer))
            {
                using (CryptoStream cryptoStream = new CryptoStream((Stream)memoryStream, decryptor, CryptoStreamMode.Read))
                {
                    using (StreamReader streamReader = new StreamReader((Stream)cryptoStream))
                    {
                        return streamReader.ReadToEnd();
                    }
                }
            }
        }
    }  


    public ResponseObj SubmitSigIn(RequestObj reqObj)
    {
        
        if (string.IsNullOrEmpty(reqObj.Item0.Trim()))
        {
            return myMessage("0", "Warning", "Email required.");
        }
        if (!ValidateEmail(reqObj.Item0.Trim()))
        {
            return myMessage("0", "Warning", "Invalid email address.");
        }
        if (string.IsNullOrEmpty(reqObj.Item1.Trim()))
        {
            return myMessage("0", "Warning", "Password required.");
        }
        User usr = new User();
        ResponseObj resObj = new ResponseObj();        
        try
        {
            string encrypted_password = EncryptString(key, reqObj.Item1.Trim());            
            sql = "SELECT fld_Id," +
                     "fld_FirstName," +
                     "fld_LastName," +
                     "fld_Email " +
                     "FROM tbl_users " +
                     "WHERE fld_email= @email " +
                     "AND fld_password = @password " +
                     "AND fld_status = '1'";
            cmd = new MySqlCommand(sql);
            cmd.Parameters.AddWithValue("@email", reqObj.Item0.Trim());
            cmd.Parameters.AddWithValue("@password", encrypted_password);
            dr = db.Read(cmd);
            if (dr.Read())
            {
                if (dr["fld_id"].ToString() != "")
                {
                    resObj.rcode = "1";
                    usr.UserId = dr["fld_Id"].ToString();
                    usr.FirstName = dr["fld_FirstName"].ToString();
                    usr.LastName = dr["fld_LastName"].ToString();
                    usr.Email = dr["fld_Email"].ToString();
                    System.Web.HttpContext.Current.Session["VDOUSR"] = usr;
                    System.Web.HttpContext.Current.Session.Timeout = 99999;
                    System.Web.Security.FormsAuthentication.SetAuthCookie(dr["fld_Id"].ToString(), false);
                }
                else
                {
                    resObj.rcode = "0";
                    resObj.rtitle = "Error";
                    resObj.rmsg = "Email or password may not be correct.";
                }
            }
            else
            {
                resObj.rcode = "0";
                resObj.rtitle = "Error";
                resObj.rmsg = "Email or password may not be correct.";
            }
            dr.Close();
        }
        catch (Exception err)
        {
            throw err;
        }
        finally
        {
            db.Close();
        }
        return resObj;
    }

    #endregion
    
    #region VALIDATION
    private bool ValidateEmail(string Email)
    {
        bool flag = false;
        Regex regex = new Regex(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$");
        Match match = regex.Match(Email);
        if (match.Success)
            flag = true;
        return flag;
    }
    #endregion
      
    #region CUSTOM MESSAGE
    private ResponseObj myMessage(string code, string title, string message)
    {
        ResponseObj resObj = new ResponseObj();
        resObj.rcode = code;
        resObj.rtitle = title;
        resObj.rmsg = message;
        return resObj;
    }
    #endregion
}