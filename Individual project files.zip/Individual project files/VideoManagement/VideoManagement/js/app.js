


/*-------------SETTINGS - SAVE SHOW ENTRIES-------------*/

function SaveDefaultShowEntry() {
    var entriesok = true;
    var ddls = ["ddl_settings_page_name", "ddl_settings_entries"];
    var uaindex = "0";
    if (!validateDDLs(ddls, uaindex)) {
        entriesok = false;
    }
    if (entriesok) {
        var obj = {};
        obj.Item0 = $("#ddl_settings_page_name").val();
        obj.Item1 = $("#ddl_settings_entries").val();
        $.ajax({
            type: "POST",
            url: "../api/HSD/SaveDefaultShowEntry",
            data: JSON.stringify(obj),
            contentType: "application/json; charset=utf-8",
            dataType: "JSON",
            success: OnSuccessSaveDefaultShowEntry,
            failure: function (response) {
                //alert(response.d);
            },
            error: function (response) {
                //alert(response.d);
            }
        });
    }
}

function OnSuccessSaveDefaultShowEntry(response) {
    switch (response.rcode) {
        case "0":
            InfoPopup(response.rtitle, response.rmsg);
            break;
        case "1":
            SuccessPopup(response.rtitle, response.rmsg);
            break;
    }
}


function LoadDefaultShowEntry() {
    var obj = {};
    obj.Item0 = $("#ddl_settings_page_name").val();
    $.ajax({
        type: "POST",
        url: "../api/HSD/LoadDefaultShowEntry",
        data: JSON.stringify(obj),
        contentType: "application/json; charset=utf-8",
        dataType: "JSON",
        success: OnSuccessLoadDefaultShowEntry,
        failure: function (response) {
            //alert(response.d);
        },
        error: function (response) {
            //alert(response.d);
        }
    });
}

function OnSuccessLoadDefaultShowEntry(response) {
    switch (response.rcode) {
        case "0":
            InfoPopup(response.rtitle, response.rmsg);
            break;
        case "1":
            $("#ddl_settings_entries").val(response.Item0);
            break;
    }
}



function LoadSettingsPageName() {
    var obj = {};
    $.ajax({
        type: "POST",
        url: "../api/HSD/LoadSettingsPageName",
        data: JSON.stringify(obj),
        contentType: "application/json; charset=utf-8",
        dataType: "JSON",
        success: OnSuccessLoadSettingsPageName,
        failure: function (response) {
            //alert(response.d);
        },
        error: function (response) {
            //alert(response.d);
        }
    });
}

function OnSuccessLoadSettingsPageName(data) {
    PopulateControl(data, $("#ddl_settings_page_name"));
}


/*-------------END------------------*/

/*-------------CATEGORY PAGE------------------*/

function CategoryMoveUp(id,showinID) {
    var obj = {};
    obj.Item0 = id;
    obj.Item1 = showinID;
    $.ajax({
        type: "POST",
        url: "../api/HSD/CategoryMoveUp",
        data: JSON.stringify(obj),
        contentType: "application/json; charset=utf-8",
        dataType: "JSON",
        success: OnSuccessCategoryMoveUp,
        failure: function (response) {
            //alert(response.d);
        },
        error: function (response) {
            //alert(response.d);
        }
    });
}

function OnSuccessCategoryMoveUp(response) {
    switch (response.rcode) {
        case "0":
            InfoPopup(response.rtitle, response.rmsg);
            break;
        case "1":
            LoadCategoryGrid();
            break;
    }
}

function DeletCategory(id) {
    swal({
        title: "",
        text: "Are you sure to delete this category?",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "Yes, delete it!",
        cancelButtonText: "No, keep it!",
        closeOnConfirm: false,
        closeOnCancel: false
    },
            function (isConfirm) {
                if (isConfirm) {
                    var obj = {};
                    obj.Item0 = id;
                    $.ajax({
                        type: "POST",
                        url: "../api/HSD/DeletCategory",
                        data: JSON.stringify(obj),
                        contentType: "application/json; charset=utf-8",
                        dataType: "json",
                        success: OnSuccessDeletCategory,
                        failure: function (response) {
                            //alert(response.d);
                        },
                        error: function (response) {
                            //alert(response.d);
                        }
                    });
                } else {
                    swal("Cancelled", "", "error");
                }
            });
}

function OnSuccessDeletCategory(response) {
    switch (response.rcode) {
        case "0":
            InfoPopup(response.rtitle, response.rmsg);
            break;
        case "1":
            SuccessPopup(response.rtitle, response.rmsg);
            LoadCategoryGrid();
            break;
    }
}

function LoadCategoryForEdit(cid) {
    ClearCategoryModal();
    $("#hid_PageCategoryID").val(cid);
    var obj = {};
    obj.Item0 = $("#hid_PageCategoryID").val();
    $.ajax({
        type: "POST",
        url: "../api/HSD/LoadCategoryForEdit",
        data: JSON.stringify(obj),
        contentType: "application/json; charset=utf-8",
        dataType: "JSON",
        success: OnSuccessLoadCategoryForEdit,
        failure: function (response) {
            //alert(response.d);
        },
        error: function (response) {
            //alert(response.d);
        }
    });
}

function OnSuccessLoadCategoryForEdit(response) {
    switch (response.rcode) {
        case "0":
            InfoPopup(response.rtitle, response.rmsg);
            break;
        case "1":
            $("#h_CategoryTitle").html("Edit Category");
            $("#hid_PageCategoryID").val(response.Item0);
            $("#ddl_MdlCategoryShowInPage").val(response.Item1);
            $("#txt_CategoryName").val(response.Item2);
            $("#ddl_MdlCategoryStatus").val(response.Item3);
            $("#Modl_Category").modal("show");
            break;
    }
}

function SaveCategory() {
    var entriesok = true;
    var txtbxs = ["txt_CategoryName"];
    if (!validateTxtBxs(txtbxs)) {
        entriesok = false;
    }

    var ddls = [ "ddl_MdlCategoryShowInPage"];
    var uaindex = "0";
    if (!validateDDLs(ddls, uaindex)) {
        entriesok = false;
    }

    if (entriesok) {

        var obj = {};
        obj.Item0 = $("#hid_PageCategoryID").val();
        obj.Item1 = $("#txt_CategoryName").val();
        obj.Item2 = $("#ddl_MdlCategoryShowInPage").val();
        obj.Item3 = $("#ddl_MdlCategoryStatus").val();
        $.ajax({
            type: "POST",
            url: "../api/HSD/SaveCategory",
            data: JSON.stringify(obj),
            contentType: "application/json; charset=utf-8",
            dataType: "JSON",
            success: OnSuccessSaveCategory,
            failure: function (response) {
                //alert(response.d);
            },
            error: function (response) {
                //alert(response.d);
            }
        });
    }
}

function OnSuccessSaveCategory(response) {
    switch (response.rcode) {
        case "0":
            InfoPopup(response.rtitle, response.rmsg);
            break;
        case "1":
            $("#hid_PageCategoryID").val(response.Item0);
            $("#ddl_CategoryShowInPage").val($("#ddl_MdlCategoryShowInPage").val());
            $("#ddl_CategoryStatus").val($("#ddl_MdlCategoryStatus").val());
            CloseCategoryModel();
            LoadCategoryGrid();
            SuccessPopup(response.rtitle, response.rmsg);
            break;
    }
}

function ClearCategoryModal() {
    $("#h_CategoryTitle").html("Add Category");
    $("#ddl_MdlCategoryShowInPage").val("0");
    $("#txt_CategoryName").val("");
    $("#ddl_MdlCategoryStatus").val("1");    
    $("#hid_PageCategoryID").val("");   
    $("#txt_CategoryName").css("background", "#FFFFFF");
    $("#ddl_MdlCategoryShowInPage").css("background", "#FFFFFF");
    $("#ddl_MdlCategoryStatus").css("background", "#FFFFFF");
}

function ShowAddCategoryModal() {
    ClearCategoryModal();
    $("#Modl_Category").modal("show");
}

function CloseCategoryModel() {
    $("#txt_CategoryName").val("");
    $("#hid_PageCategoryID").val("");
    $("#ddl_MdlCategoryShowInPage").val("0");
    $("#ddl_MdlCategoryStatus").val("1");
    $("#Modl_Category").modal("hide");
}


function LoadCategoryGrid() {
    var obj = {};
    obj.Item0 = $("#ddl_CategoryShowInPage").val();
    obj.Item1 = $("#ddl_CategoryStatus").val();
    $.ajax({
        type: "POST",
        url: "../api/HSD/LoadCategoryGrid",
        data: JSON.stringify(obj),
        contentType: "application/json; charset=utf-8",
        dataType: "JSON",
        success: OnSuccessLoadCategoryGrid,
        failure: function (response) {
            //alert(response.d);
        },
        error: function (response) {
            //alert(response.d);
        }
    });
}

function OnSuccessLoadCategoryGrid(response) {
    switch (response.rcode) {
        case "0":
            InfoPopup(response.rtitle, response.rmsg);
            break;
        case "1":

            if($("#ddl_CategoryShowInPage").val() == "0")
            {
                $("#div_CategoryGrid").html("<div class='no-results'><h3>PLEASE SELECT A SHOW IN PAGE</h3><p></p></div>");
            }
            else{
                $("#div_CategoryGrid").html(response.Item0);
                $("#tblCategory").DataTable({
                    "pageLength": 10,
                    "paging": true,
                    "searching": true,
                    "ordering": false,
                    "info": true
                });
            }              
            break;
    }
}

function LoadCategoryShowinpage() {
    var obj = {};
    $.ajax({
        type: "POST",
        url: "../api/HSD/LoadCategoryShowinpage",
        data: JSON.stringify(obj),
        contentType: "application/json; charset=utf-8",
        dataType: "JSON",
        success: OnSuccessLoadCategoryShowinpage,
        failure: function (response) {
            //alert(response.d);
        },
        error: function (response) {
            //alert(response.d);
        }
    });
}

function OnSuccessLoadCategoryShowinpage(data) {
    PopulateControl(data, $("#ddl_CategoryShowInPage"));
    PopulateControl(data, $("#ddl_MdlCategoryShowInPage"));
    LoadCategoryGrid();
}
/*---------------END----------------------*/

/*-------------SHOW IN PAGE------------------*/

$("#chk_addbanneradd").click(function () {
    $("#div_BannerAdvertisement").hide();
    if ($(this).is(":checked")) {
        $("#div_BannerAdvertisement").show();
    }
});

function ShowInPageMoveUp(id) {
    var obj = {};
    obj.Item0 = id;
    $.ajax({
        type: "POST",
        url: "../api/HSD/ShowInPageMoveUp",
        data: JSON.stringify(obj),
        contentType: "application/json; charset=utf-8",
        dataType: "JSON",
        success: OnSuccessShowInPageMoveUp,
        failure: function (response) {
            //alert(response.d);
        },
        error: function (response) {
            //alert(response.d);
        }
    });
}

function OnSuccessShowInPageMoveUp(response) {
    switch (response.rcode) {
        case "0":
            InfoPopup(response.rtitle, response.rmsg);
            break;
        case "1":
            LoadShowInPageGrid();
            break;
    }
}


function DeletShowInPage(id) {
    swal({
        title: "",
        text: "Are you sure to delete this page?",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "Yes, delete it!",
        cancelButtonText: "No, keep it!",
        closeOnConfirm: false,
        closeOnCancel: false
    },
            function (isConfirm) {
                if (isConfirm) {
                    var obj = {};
                    obj.Item0 = id;
                    $.ajax({
                        type: "POST",
                        url: "../api/HSD/DeletShowInPage",
                        data: JSON.stringify(obj),
                        contentType: "application/json; charset=utf-8",
                        dataType: "json",
                        success: OnSuccessDeletShowInPage,
                        failure: function (response) {
                            //alert(response.d);
                        },
                        error: function (response) {
                            //alert(response.d);
                        }
                    });
                } else {
                    swal("Cancelled", "", "error");
                }
            });
}
function OnSuccessDeletShowInPage(response) {
    switch (response.rcode) {
        case "0":
            InfoPopup(response.rtitle, response.rmsg);
            break;
        case "1":
            SuccessPopup(response.rtitle, response.rmsg);
            LoadShowInPageGrid();
            break;
    }
}

function LoadShowInPageForEdit(sid) {
    ClearShowInPageModal();
    $("#hid_ShowInPageID").val(sid);
    var obj = {};
    obj.Item0 = $("#hid_ShowInPageID").val();
    $.ajax({
        type: "POST",
        url: "../api/HSD/LoadShowInPageForEdit",
        data: JSON.stringify(obj),
        contentType: "application/json; charset=utf-8",
        dataType: "JSON",
        success: OnSuccessLoadShowInPageForEdit,
        failure: function (response) {
            //alert(response.d);
        },
        error: function (response) {
            //alert(response.d);
        }
    });
}

function OnSuccessLoadShowInPageForEdit(response) {
    switch (response.rcode) {
        case "0":
            InfoPopup(response.rtitle, response.rmsg);
            break;
        case "1":
            $("#h_showinpage_title").html("Edit Show In Page");
            $("#hid_ShowInPageID").val(response.Item0);
            $("#txt_ShowInPageName").val(response.Item1);
            $("#ddl_MdlShowinPage_Status").val(response.Item2);
            $("#ddl_MdlShowinPageMenu").val(response.Item3);
            $("#txt_ShowInPageUrl").val(response.Item4);
            $("#txt_ShowInPageTitle").val(response.Item5);
            $("#txt_ShowInPageSEOKeyWords").val(response.Item6);
            $("#txt_ShowInPageSEODescrption").val(response.Item7);
            if (response.Item8 == "1") {
                $("#chk_addbanneradd").prop("checked", true);
                $("#div_BannerAdvertisement").show();
                $("#sn_banneradd").code(response.Item9);
            }
            else {
                $("#chk_addbanneradd").prop("checked", false);
                $("#div_BannerAdvertisement").hide();
                $("#sn_banneradd").code("");
            }
            
            switch (response.Item10) {
                case "1":
                    $("#ddl_MdlShowinPageMenu").prop("disabled", true);
                    $("#txt_ShowInPageName").prop("disabled", true);
                    $("#txt_ShowInPageUrl").prop("disabled", true);                    

                    $("#ddl_MdlShowinPageMenu").css("background", "#EFEFF2");
                    $("#txt_ShowInPageName").css("background", "#EFEFF2");
                    $("#txt_ShowInPageUrl").css("background", "#EFEFF2");                    
                    break;

                case "0":
                    $("#ddl_MdlShowinPageMenu").prop("disabled", false);
                    $("#txt_ShowInPageName").prop("disabled", false);
                    $("#txt_ShowInPageUrl").prop("disabled", false);                   

                    $("#ddl_MdlShowinPageMenu").css("background", "#FFFFFF");
                    $("#txt_ShowInPageName").css("background", "#FFFFFF");
                    $("#txt_ShowInPageUrl").css("background", "#FFFFFF");
                    
                    break;
            } 
            $("#Modl_ShowInPage").modal("show");
            break;
    }
}
function SaveShowInPage() {
    var entriesok = true;
    var txtbxs = ["txt_ShowInPageName","txt_ShowInPageUrl"];
    if (!validateTxtBxs(txtbxs)) {
        entriesok = false;
    }

    var ddls = ["ddl_MdlShowinPageMenu"];
    var uaindex = "0";
    if (!validateDDLs(ddls, uaindex)) {
        entriesok = false;
    }

    if ($("#chk_addbanneradd").is(":checked")) {
        $("#hid_banneradd").val($("#sn_banneradd").code());
        var banneradd = $("#sn_banneradd").code();
        if (banneradd == (('') || ('<p><br></p>') || ('<p><br></p><p><br></p>') || ('<p><br></p><p><br></p><p><br></p>'))) {
            InfoPopup("Required", "Please add banner advertisement.");
            entriesok = false;
        }
    }
    else
    {
        $("#hid_banneradd").val("");
        $("#sn_banneradd").code("");
    }

    if (entriesok) {
        var obj = {};
        obj.Item0 = $("#hid_ShowInPageID").val();
        obj.Item1 = $("#txt_ShowInPageName").val();
        obj.Item2 = $("#ddl_MdlShowinPage_Status").val();
        obj.Item3 = $("#ddl_MdlShowinPageMenu").val();
        obj.Item4 = $("#txt_ShowInPageUrl").val();
        obj.Item5 = $("#txt_ShowInPageTitle").val();
        obj.Item6 = $("#txt_ShowInPageSEOKeyWords").val();
        obj.Item7 = $("#txt_ShowInPageSEODescrption").val();
        obj.Item8 = "0";
        obj.Item9 = "";
        if ($("#chk_addbanneradd").is(":checked")) {
            obj.Item8 = "1";
            obj.Item9 = $("#hid_banneradd").val();
        }   
        $.ajax({
            type: "POST",
            url: "../api/HSD/SaveShowInPage",
            data: JSON.stringify(obj),
            contentType: "application/json; charset=utf-8",
            dataType: "JSON",
            success: OnSuccessSaveShowInPage,
            failure: function (response) {
                //alert(response.d);
            },
            error: function (response) {
                //alert(response.d);
            }
        });
    }
}

function OnSuccessSaveShowInPage(response) {
    switch (response.rcode) {
        case "0":
            InfoPopup(response.rtitle, response.rmsg);
            break;
        case "1":
            $("#hid_ShowInPageID").val(response.Item0);
            $("#ddl_ShowInPage_Status").val($("#ddl_MdlShowinPage_Status").val());
            CloseShowInPageModel();
            LoadShowInPageGrid();
            SuccessPopup(response.rtitle, response.rmsg);
            break;
    }
}
function ClearShowInPageModal() {
    $("#txt_ShowInPageName").val("");
    $("#txt_ShowInPageUrl").val("");
    $("#txt_ShowInPageTitle").val("");
    $("#txt_ShowInPageSEOKeyWords").val("");
    $("#txt_ShowInPageSEODescrption").val("");
    $("#hid_ShowInPageID").val("");
    $("#ddl_MdlShowinPage_Status").val("1");
    $("#ddl_MdlShowinPageMenu").val("2");
    $("#h_showinpage_title").html("Add Show In Page");
    $("#txt_ShowInPageName").css("background", "#FFFFFF");
    $("#txt_ShowInPageUrl").css("background", "#FFFFFF");
    $("#ddl_MdlShowinPageMenu").css("background", "#FFFFFF");
}

function ShowAddShowInPageModal() {
    ClearShowInPageModal();
    $("#Modl_ShowInPage").modal("show");
}
function CloseShowInPageModel() {
    $("#txt_ShowInPageName").val("");
    $("#txt_ShowInPageUrl").val("");
    $("#txt_ShowInPageTitle").val("");
    $("#txt_ShowInPageSEOKeyWords").val("");
    $("#txt_ShowInPageSEODescrption").val("");
    $("#hid_ShowInPageID").val("");    
    $("#ddl_MdlShowInPage_Status").val("1");
    $("#h_showinpage_title").html("Add Show In Page");
    $("#ddl_MdlShowinPageMenu").val("0");
    $("#Modl_ShowInPage").modal("hide");
}
function LoadShowInPageGrid() {
    var obj = {};
    obj.Item0 = $("#ddl_ShowInPage_Status").val();
    $.ajax({
        type: "POST",
        url: "../api/HSD/LoadShowInPageGrid",
        data: JSON.stringify(obj),
        contentType: "application/json; charset=utf-8",
        dataType: "JSON",
        success: OnSuccessLoadShowInPageGrid,
        failure: function (response) {
            //alert(response.d);
        },
        error: function (response) {
            //alert(response.d);
        }
    });
}

function OnSuccessLoadShowInPageGrid(response) {
    switch (response.rcode) {
        case "0":
            InfoPopup(response.rtitle, response.rmsg);
            break;
        case "1":
            $("#div_ShowInPage_Grid").html(response.Item0);
            $("#tblShowInPage").DataTable({
                "pageLength": $("#hid_PageDefaultEntry").val(),
                "paging": true,
                "searching": true,
                "ordering": false,
                "info": true
            });
            break;
    }
}
/*-------------END------------------*/

/*-------------STORE PAGE------------------*/

function StoreMoveUp(id) {
    var obj = {};
    obj.Item0 = id;
    $.ajax({
        type: "POST",
        url: "../api/HSD/StoreMoveUp",
        data: JSON.stringify(obj),
        contentType: "application/json; charset=utf-8",
        dataType: "JSON",
        success: OnSuccessStoreMoveUp,
        failure: function (response) {
            //alert(response.d);
        },
        error: function (response) {
            //alert(response.d);
        }
    });
}

function OnSuccessStoreMoveUp(response) {
    switch (response.rcode) {
        case "0":
            InfoPopup(response.rtitle, response.rmsg);
            break;
        case "1":
            LoadStoreGrid();
            break;
    }
}

function DeletStore(id) {
    swal({
        title: "",
        text: "Are you sure to delete this store?",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "Yes, delete it!",
        cancelButtonText: "No, keep it!",
        closeOnConfirm: false,
        closeOnCancel: false
    },
            function (isConfirm) {
                if (isConfirm) {
                    var obj = {};
                    obj.Item0 = id;
                    $.ajax({
                        type: "POST",
                        url: "../api/HSD/DeletStore",
                        data: JSON.stringify(obj),
                        contentType: "application/json; charset=utf-8",
                        dataType: "json",
                        success: OnSuccessDeletStore,
                        failure: function (response) {
                            //alert(response.d);
                        },
                        error: function (response) {
                            //alert(response.d);
                        }
                    });
                } else {
                    swal("Cancelled", "", "error");
                }
            });
}

function OnSuccessDeletStore(response) {
    switch (response.rcode) {
        case "0":
            InfoPopup(response.rtitle, response.rmsg);
            break;
        case "1":
            SuccessPopup(response.rtitle, response.rmsg);
            LoadStoreGrid();
            break;
    }
}

function LoadStoreForEdit(sid) {
    ClearStoreModal();
    $("#hid_storeID").val(sid);
    var obj = {};
    obj.Item0 = $("#hid_storeID").val();
    $.ajax({
        type: "POST",
        url: "../api/HSD/LoadStoreForEdit",
        data: JSON.stringify(obj),
        contentType: "application/json; charset=utf-8",
        dataType: "JSON",
        success: OnSuccessLoadStoreForEdit,
        failure: function (response) {
            //alert(response.d);
        },
        error: function (response) {
            //alert(response.d);
        }
    });
}

function OnSuccessLoadStoreForEdit(response) {
    switch (response.rcode) {
        case "0":
            InfoPopup(response.rtitle, response.rmsg);
            break;
        case "1": 
            $("#hid_storeID").val(response.Item0);
            $("#txt_store").val(response.Item1);
            $("#ddl_MdlStore_Status").val(response.Item2);
            $("#h_store_title").html("Edit store");
            $("#Modl_Store").modal("show");
            break;
    }
}

function SaveStore() {  
    var entriesok = true;    
    var txtbxs = ["txt_store"];
    if (!validateTxtBxs(txtbxs)) {
        entriesok = false;
    } 

    if (entriesok) {

        var obj = {};
        obj.Item0 = $("#hid_storeID").val();
        obj.Item1 = $("#txt_store").val();
        obj.Item2 = $("#ddl_MdlStore_Status").val();
        $.ajax({
            type: "POST",
            url: "../api/HSD/SaveStore",
            data: JSON.stringify(obj),
            contentType: "application/json; charset=utf-8",
            dataType: "JSON",
            success: OnSuccessSaveStore,
            failure: function (response) {
                //alert(response.d);
            },
            error: function (response) {
                //alert(response.d);
            }
        });
    }   
}

function OnSuccessSaveStore(response) {
    switch (response.rcode) {
        case "0":
            InfoPopup(response.rtitle, response.rmsg);
            break;
        case "1":
            $("#hid_storeID").val(response.Item0);
            $("#ddl_Store_Status").val($("#ddl_MdlStore_Status").val());
            CloseStoreModel();
            LoadStoreGrid();
            SuccessPopup(response.rtitle, response.rmsg);
            break;
    }
}

function ClearStoreModal() {
    $("#txt_store").val("");
    $("#hid_storeID").val("");
    $("#ddl_MdlStore_Status").val("1");
    $("#h_store_title").html("Add store");
    $("#txt_store").css("background", "#FFFFFF");   
}

function ShowAddStoreModal() {
    ClearStoreModal();
    $("#Modl_Store").modal("show");
}

function CloseStoreModel() {
    $("#txt_store").val("");
    $("#hid_storeID").val("");
    $("#ddl_MdlStore_Status").val("1");
    $("#Modl_Store").modal("hide");
}

function LoadStoreGrid() {
    var obj = {};
    obj.Item0 = $("#ddl_Store_Status").val();
    $.ajax({
        type: "POST",
        url: "../api/HSD/LoadStoreGrid",
        data: JSON.stringify(obj),
        contentType: "application/json; charset=utf-8",
        dataType: "JSON",
        success: OnSuccessLoadStoreGrid,
        failure: function (response) {
            //alert(response.d);
        },
        error: function (response) {
            //alert(response.d);
        }
    });
}

function OnSuccessLoadStoreGrid(response) {
    switch (response.rcode) {
        case "0":
            InfoPopup(response.rtitle, response.rmsg);
            break;
        case "1":
            $("#div_Store_Grid").html(response.Item0);
            $("#tblStores").DataTable({
                "pageLength": $("#hid_PageDefaultEntry").val(),
                "paging": true,
                "searching": true,
                "ordering": false,
                "info": true
            });
            break;
    }
}

/*-------------END------------------*/


/*-------------PRODUCT PAGE------------------*/
function ShowASIN()
{
    switch ($("#ddl_mdl_store").val()) {
        case "1":
            $("#div_ASIN").show();
            break;
        default:
            $("#txt_ASIN").val("");
            $("#txt_ASIN").css("background", "#FFFFFF");
            $("#div_ASIN").hide();
            break;
    }
}

function ProductLookup()
{
    var entriesok = true;
    var ddls = ["ddl_lookup_store"];
    var uaindex = "0";
    if (!validateDDLs(ddls, uaindex)) {
        entriesok = false;
    }
    var txtbxs = ["txt_productNumber"];
    if (!validateTxtBxs(txtbxs)) {
        entriesok = false;
    }    
    if (entriesok) {
        var obj = {};
        obj.Item0 = $("#ddl_lookup_store").val();
        obj.Item1 = $("#txt_productNumber").val();
        $.ajax({
            type: "POST",
            url: "../api/HSD/ProductLookup",
            data: JSON.stringify(obj),
            contentType: "application/json; charset=utf-8",
            dataType: "JSON",
            success: OnSuccessProductLookup,
            failure: function (response) {
                //alert(response.d);
            },
            error: function (response) {
                //alert(response.d);
            }
        });
    }
}

function OnSuccessProductLookup(response) {
    switch (response.rcode) {
        case "0":
            InfoPopup(response.rtitle, response.rmsg);
            break;
        case "1":
            $("#ddl_mdl_store").val($("#ddl_lookup_store").val());
            $("#div_ASIN").show();
            $("#txt_ASIN").val($("#txt_productNumber").val());
            $("#txt_productName").val(response.Item0);            
            if (response.Item1 != "") {
                $("#ddl_img_input_method").val("2");
                $("#div_UploadImg").hide();
                $("#div_InputImgLink").show();               
                $("#txt_image_link").val(response.Item1);
                $("#img_product").attr("src", response.Item1 + '?dt=' + (new Date()));
                $("#img_product").attr("title", response.Item0);
                $("#img_product").attr("alt", response.Item0);
                $("#div_img_product").show();
            }
            $("#txt_price").val(response.Item2);
            $("#txt_offerPrice").val(response.Item3);
            $("#txt_storeLink").val(response.Item4);
            CloseLookUpModel();
            break;
    }
}

function ShowLookUpModal() {
    $("#ddl_lookup_store").val("1");
    $("#txt_productNumber").val("");
    $("#ddl_lookup_store").css("background", "#FFFFFF");
    $("#txt_productNumber").css("background", "#FFFFFF");    
    $("#Modl_product").modal("hide"); 
    $("#Modl_LookUp").modal("show");
    $("body").removeAttr("style");    
}

function CloseLookUpModel() {
    $("#ddl_lookup_store").val("0");
    $("#txt_productNumber").val("");
    $("#ddl_lookup_store").css("background", "#FFFFFF");
    $("#txt_productNumber").css("background", "#FFFFFF");
    $("#Modl_LookUp").modal("hide");
    $("#Modl_product").modal("show");
    $("body").removeAttr("style");
    
}

function LoadShowInFilter() {
    var obj = {};
    $.ajax({
        type: "POST",
        url: "../api/HSD/LoadShowInFilter",
        data: JSON.stringify(obj),
        contentType: "application/json; charset=utf-8",
        dataType: "JSON",
        success: OnSuccessLoadShowInFilter,
        failure: function (response) {
            //alert(response.d);
        },
        error: function (response) {
            //alert(response.d);
        }
    });
}

function OnSuccessLoadShowInFilter(response) {
    $("#div_showin_filter").html(response.Item0);    
    $("#ddl_showin_filter").multiselect({
        selectAllValue: 'multiselect-all',
        enableCaseInsensitiveFiltering: true,
        enableFiltering: true,
        includeSelectAllOption: true,
        //width: '450',
        maxHeight: '150',
        buttonWidth: '200',
        onChange: function (element, checked) {            
            LoadCategoryFilter();
        },
        onSelectAll: function (element, checked) {
            LoadCategoryFilter();
        },
        onDeselectAll: function (element, checked) {
            LoadCategoryFilter();
        }        
    });
    $("#ddl_showin_filter").multiselect("refresh");
    LoadCategoryFilter();
}

function LoadCategoryFilter() {
    var ShowInVal = [];
    $("#ddl_showin_filter :selected").each(function (i, selected) {
        ShowInVal[i] = $(selected).val();
    });
    var obj = {};
    obj.Item0 = ShowInVal.join(",");
    $.ajax({
        type: "POST",
        url: "../api/HSD/LoadCategoryFilter",
        data: JSON.stringify(obj),
        contentType: "application/json; charset=utf-8",
        dataType: "JSON",
        success: OnSuccessLoadCategoryFilter,
        failure: function (response) {
            //alert(response.d);
        },
        error: function (response) {
            //alert(response.d);
        }
    });
}

function OnSuccessLoadCategoryFilter(response) {    
    $("#div_category_filter").html(response.Item0);
    $("#ddl_category_filter").multiselect({
        selectAllValue: 'multiselect-all',
        enableCaseInsensitiveFiltering: true,
        enableFiltering: true,
        includeSelectAllOption: true,
        //width: '450',
        maxHeight: '150',
        buttonWidth: '200',
        onChange: function (element, checked) {
            LoadProductGrid();
        },
        onSelectAll: function (element, checked) {
            LoadProductGrid();
        },
        onDeselectAll: function (element, checked) {
            LoadProductGrid();
        }
    });
    $("#ddl_category_filter").multiselect("refresh");
    LoadProductGrid();
}

function LoadShowIn() {
    var obj = {};
    $.ajax({
        type: "POST",
        url: "../api/HSD/LoadShowIn",
        data: JSON.stringify(obj),
        contentType: "application/json; charset=utf-8",
        dataType: "JSON",
        success: OnSuccessLoadShowIn,
        failure: function (response) {
            //alert(response.d);
        },
        error: function (response) {
            //alert(response.d);
        }
    });
}

function OnSuccessLoadShowIn(response) {
    $("#div_showin").html(response.Item0);    
    $("#ddl_showin").multiselect({
        selectAllValue: 'multiselect-all',
        enableCaseInsensitiveFiltering: true,
        enableFiltering: true,
        includeSelectAllOption: true,
        //width: '450',
        maxHeight: '150',
        buttonWidth: '200',
        onChange: function (element, checked) {
            LoadCategory();
        },
        onSelectAll: function (element, checked) {
            LoadCategory();
        },
        onDeselectAll: function (element, checked) {
            LoadCategory();
        }
    });
    $("#ddl_showin").multiselect("refresh");
    LoadCategory();
}

function LoadCategory() {
    var ShowInVal = [];
    $("#ddl_showin :selected").each(function (i, selected) {
        ShowInVal[i] = $(selected).val();
    });
    var obj = {};
    obj.Item0 = ShowInVal.join(",");
    $.ajax({
        type: "POST",
        url: "../api/HSD/LoadCategory",
        data: JSON.stringify(obj),
        contentType: "application/json; charset=utf-8",
        dataType: "JSON",
        success: OnSuccessLoadCategory,
        failure: function (response) {
            //alert(response.d);
        },
        error: function (response) {
            //alert(response.d);
        }
    });
}

function OnSuccessLoadCategory(response) {
    $("#div_category").html(response.Item0);
    $("#ddl_category").multiselect({
        selectAllValue: 'multiselect-all',
        enableCaseInsensitiveFiltering: true,
        enableFiltering: true,
        includeSelectAllOption: true,
        //width: '450',
        maxHeight: '150',
        buttonWidth: '200'        
    });    
    if ($.trim($("#hid_categoryID").val()).length > 0) {
        var arr = $.trim($("#hid_categoryID").val()).split(',');
        for (var i = 0; i < arr.length; i++) {
            $("#ddl_category").find("option[value=" + arr[i] + "]").prop("selected", true);
        }
    }
    $("#ddl_category").multiselect("refresh");   
}

function UploadProdctImage() {
    // Checking whether FormData is available in browser  
    if (window.FormData !== undefined) {
        var fileUpload = $("#img_product_file").get(0);
        var files = fileUpload.files;
        // Create FormData object  
        var fileData = new FormData();
        // Looping over all files and add it to FormData object  
        for (var i = 0; i < files.length; i++) {
            fileData.append(files[i].name, files[i]);
        }
        // Adding one more key to FormData object         


        fileData.append("prdID", $("#hid_productID").val());
        $.ajax({
            type: "POST",
            url: "../api/HSD/UploadProdctImage",
            enctype: 'multipart/form-data',
            contentType: false,
            processData: false,         // PREVENT AUTOMATIC DATA PROCESSING.
            cache: false,
            data: fileData, 		        // DATA OR FILES IN THIS CONTEXT.
            success: OnSuccessUploadProdctImage,
            error: function (err) {
                //alert(err.statusText);
            }
        });
    } else {
        InfoPopup("Warning","FormData is not supported.");
    }
}

function OnSuccessUploadProdctImage(response) {
    $("#img_product_file").val("");
    SuccessPopup(response.rtitle, response.rmsg);
    CloseProductModel();
    LoadProductGrid();
}

function DeletProduct(id) {
    swal({
        title: "",
        text: "Are you sure to delete this product?",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "Yes, delete it!",
        cancelButtonText: "No, keep it!",
        closeOnConfirm: false,
        closeOnCancel: false
    },
            function (isConfirm) {
                if (isConfirm) {
                    var obj = {};
                    obj.Item0 = id;
                    $.ajax({
                        type: "POST",
                        url: "../api/HSD/DeletProduct",
                        data: JSON.stringify(obj),
                        contentType: "application/json; charset=utf-8",
                        dataType: "json",
                        success: OnSuccessDeletProduct,
                        failure: function (response) {
                            //alert(response.d);
                        },
                        error: function (response) {
                            //alert(response.d);
                        }
                    });
                } else {
                    swal("Cancelled", "", "error");
                }
            });
}

function OnSuccessDeletProduct(response) {
    switch (response.rcode) {
        case "0":
            InfoPopup(response.rtitle, response.rmsg);
            break;
        case "1":
            SuccessPopup(response.rtitle, response.rmsg);
            LoadProductGrid();
            break;
    }
}

function LoadProductForEdit(pid) {
    ClearProductMdal();
    $("#hid_productID").val(pid);   
    var obj = {};
    obj.Item0 = $("#hid_productID").val();
    $.ajax({
        type: "POST",
        url: "../api/HSD/LoadProductForEdit",
        data: JSON.stringify(obj),
        contentType: "application/json; charset=utf-8",
        dataType: "JSON",
        success: OnSuccessLoadProductForEdit,
        failure: function (response) {
            //alert(response.d);
        },
        error: function (response) {
            //alert(response.d);
        }
    });
}

function OnSuccessLoadProductForEdit(response) {
    switch (response.rcode) {
        case "0":
            InfoPopup(response.rtitle, response.rmsg);
            break;
        case "1":
            $("#div_ASIN").hide();
            $("#txt_ASIN").val("");
            if (response.Item1 == "1") {
                $("#div_ASIN").show();
                $("#txt_ASIN").val(response.Item15);
            }
            $("#h_lookup_title").html("Edit Product");
            $("#hid_productID").val(response.Item0);
            $("#ddl_mdl_store").val(response.Item1);            
            $("#txt_productName").val(response.Item4);
            $("#txt_price").val(response.Item5);
            $("#txt_offerPrice").val(response.Item6);
            $("#txt_productDetails").val(response.Item7);
            $("#txt_storeLink").val(response.Item8);
            $("#ddl_MdlProductStatus").val(response.Item9);
            $("#img_product").attr("src", response.Item10 + '?dt=' + (new Date()));
            $("#img_product").attr("title",response.Item4);
            $("#img_product").attr("alt", response.Item4);
            $("#div_delete_prd_img").html(response.Item11);
            $("#txt_image_link").val(response.Item13);            
            $("#ddl_img_input_method").val(response.Item14);
            $("#div_UploadImg").hide();
            $("#div_InputImgLink").hide();
            $("#div_img_product").show();
            switch (response.Item14) {
                case "1":
                    $("#div_UploadImg").show();
                    break;
                case "2":
                    $("#div_InputImgLink").show();
                    break;                
            }           
            $("#Modl_product").modal("show");            
            if (response.Item12.length > 0) {                
                var arr = response.Item12.split(',');
                for (var i = 0; i < arr.length; i++) {
                    $("#ddl_showin").find("option[value=" + arr[i] + "]").prop("selected", true);                   
                }
            }                    
            if (response.Item2.length > 0) {
                $("#hid_categoryID").val(response.Item2);              
            }
            $("#ddl_showin").multiselect("refresh");
            LoadCategory();
            var length = $("#txt_productDetails").val().length;
            var length = 300 - length;
            $("#spn_productDetailsChar").text(length);
            break;
    }
}

function DeleteThisProductImage() {
    swal({
        title: "",
        text: "Are you sure to delete this image?",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "Yes, delete it!",
        cancelButtonText: "No, keep it!",
        closeOnConfirm: false,
        closeOnCancel: false
    },
            function (isConfirm) {
                if (isConfirm) {
                    var obj = {};
                    obj.Item0 = $("#hid_productID").val();
                    $.ajax({
                        type: "POST",
                        url: "../api/HSD/DeleteThisProductImage",
                        data: JSON.stringify(obj),
                        contentType: "application/json; charset=utf-8",
                        dataType: "json",
                        success: OnSuccessDeleteThisProductImage,
                        failure: function (response) {
                            //alert(response.d);
                        },
                        error: function (response) {
                            //alert(response.d);
                        }
                    });
                    swal.close();
                } else {
                    swal.close();
                }
            });
}

function OnSuccessDeleteThisProductImage(response) {
    LoadProductForEdit($("#hid_productID").val());
}

$("#txt_productDetails").keyup(function () {
    var length = $(this).val().length;
    var length = 300 - length;
    $("#spn_productDetailsChar").text(length);
});

function SaveProductIfNoShowInPage() {
    swal({
        title: "",
        text: "Are you sure to add this product with out show in any pages?",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: "#7AB900",
        confirmButtonText: "Yes!",
        cancelButtonText: "No",
        closeOnConfirm: false,
        closeOnCancel: false
    },
            function (isConfirm) {
                if (isConfirm) {                    
                    SaveProduct();                    
                } else {
                    swal.close();
                }
            });
}

function SaveProductCall() {
    var showIn = [];
    $("#ddl_showin :selected").each(function (i, selected) {
        showIn.push($(selected).val());
    });    
    if (showIn.length > 0) {
        SaveProduct();
    }
    else {
        SaveProductIfNoShowInPage()();
    }    
}

$("#ddl_img_input_method").change(function () {
    $("#div_UploadImg").hide();
    $("#div_InputImgLink").hide();
    $("#div_img_product").hide();
    switch (this.value) {        
        case "1":
            $("#div_UploadImg").show();
            if ($("#hid_productID").val() != "") {
                $("#div_img_product").show();
            }
            break;
        case "2":            
            $("#div_InputImgLink").show();
            if ($("#hid_productID").val() != "") {
                $("#div_img_product").show();
            }
            break;        
    }    
});

function SaveProduct() {   

    var entriesok = true;
    var ddls = ["ddl_mdl_store", "ddl_img_input_method"];
    var uaindex = "0";
    if (!validateDDLs(ddls, uaindex)) {
        entriesok = false;
    }
    var txtbxs = ["txt_productName", "txt_productDetails", "txt_price", "txt_storeLink"];
    if (!validateTxtBxs(txtbxs)) {
        entriesok = false;
    }

    if ($("#ddl_img_input_method").val() == "2") {
        txtbxs = ["txt_image_link"];
        if (!validateTxtBxs(txtbxs)) {
            entriesok = false;
        }
    }
    if ($("#hid_productID").val() == "") {
        if ($("#ddl_img_input_method").val() == "1") {
            if (!$("#img_product_file").get(0).files.length > 0) {
                entriesok = false;
                InfoPopup("Required", "Please upload an image for this product.");
            }
        }
    }

    if ($("#ddl_mdl_store").val() == "1") {
        txtbxs = ["txt_ASIN"];
        if (!validateTxtBxs(txtbxs)) {
            entriesok = false;
        }
    }

    if (entriesok) {
        var showIn = [];
        $("#ddl_showin :selected").each(function (i, selected) {
            showIn.push($(selected).val());
        });
        var category = [];
        $("#ddl_category :selected").each(function (i, selected) {
            category.push($(selected).val());
        });
        var obj = {};
        obj.Item0 = $("#hid_productID").val();
        obj.Item1 = $("#ddl_mdl_store").val();
        obj.Item2 = $("#txt_productName").val();
        obj.Item3 = $("#txt_price").val();
        obj.Item4 = $("#txt_offerPrice").val();
        obj.Item5 = $("#txt_productDetails").val();
        obj.Item6 = $("#txt_storeLink").val();
        obj.Item7 = showIn.join(", ");
        obj.Item8 = category.join(", ");
        obj.Item9 = $("#ddl_MdlProductStatus").val();
        obj.Item10 = $("#txt_image_link").val();
        obj.Item11 = $("#ddl_img_input_method").val();
        obj.Item12 = "0";
        if ($("#ddl_img_input_method").val() == "1") {
            obj.Item12 = $("#img_product_file").get(0).files.length;
        }
        obj.Item13 = $("#txt_ASIN").val();
        $.ajax({
            type: "POST",
            url: "../api/HSD/SaveProduct",
            data: JSON.stringify(obj),
            contentType: "application/json; charset=utf-8",
            dataType: "JSON",
            success: OnSuccessSaveProduct,
            failure: function (response) {
                //alert(response.d);
            },
            error: function (response) {
                //alert(response.d);
            }
        });
    }
    else {
        swal.close();
    }
}

function OnSuccessSaveProduct(response) {
    switch (response.rcode) {
        case "0":
            InfoPopup(response.rtitle, response.rmsg);
            break;
        case "1":
            $("#hid_productID").val(response.Item0);
            $("#ddl_store").val($("#ddl_mdl_store").val());
            $("#ddl_status").val($("#ddl_MdlProductStatus").val());
            if ($("#ddl_img_input_method").val() == "1" && $("#img_product_file").get(0).files.length > 0) {
                UploadProdctImage();
            }
            else {
                SuccessPopup(response.rtitle, response.rmsg);
                CloseProductModel();
                LoadProductGrid();
            }            
            break;
    }
}

function ClearProductMdal() {
    $("#div_ASIN").hide();
    $("#hid_productID").val(""); 
    $("#ddl_mdl_store").val("0");
    $("#ddl_img_input_method").val("0");
    $("#ddl_MdlProductStatus").val("1");
    $("#txt_productName").val("");
    $("#txt_ASIN").val("");
    $("#txt_price").val("");
    $("#txt_offerPrice").val("");
    $("#txt_productDetails").val("");
    $("#txt_storeLink").val("");
    $("#txt_image_link").val("");
    $("#txt_ASIN").css("background", "#FFFFFF");
    $("#ddl_img_input_method").css("background", "#FFFFFF");
    $("#txt_image_link").css("background", "#FFFFFF");
    $("#ddl_mdl_store").css("background", "#FFFFFF");   
    $("#ddl_MdlProductStatus").css("background", "#FFFFFF");
    $("#txt_productName").css("background", "#FFFFFF");
    $("#txt_price").css("background", "#FFFFFF");
    $("#txt_offerPrice").css("background", "#FFFFFF");    
    $("#txt_storeLink").css("background", "#FFFFFF");
    $("#txt_productDetails").css("background", "#FFFFFF");
    //$("#img_product").attr("src", '../img/noimage.png?dt=' + (+new Date()));    
    $("#img_product").attr("src", "");
    $("#div_img_product").hide();
    $("#img_product_file").val("");
    $("#div_delete_prd_img").html("");
    $("#ddl_showin").multiselect("clearSelection");    
    $("#ddl_showin").multiselect("refresh");
    $("#ddl_category").multiselect("clearSelection");
    $("#ddl_category").multiselect("refresh");
    $("#hid_categoryID").val("");
    $("#div_UploadImg").hide();
    $("#div_InputImgLink").hide();
    $("#div_img_product").hide();
    $("#spn_productDetailsChar").html("300");
    $("#h_lookup_title").html("Add Product");
    
}

function ShowAddProductModal() {
    ClearProductMdal();
    $("#ddl_showin").find("option[value='1']").prop("selected", true);
    $("#ddl_showin").multiselect("refresh");
    LoadCategory();
    $("#Modl_product").modal("show");
}

function CloseProductModel()
{
    $("#Modl_product").modal("hide");
}

function LoadProductGrid() {

    var ShowInVal = [];
    $("#ddl_showin_filter :selected").each(function (i, selected) {
        ShowInVal[i] = $(selected).val();
    });

    var CategoryVal = [];
    $("#ddl_category_filter :selected").each(function (i, selected) {
        CategoryVal[i] = $(selected).val();
    });

    var obj = {};
    obj.Item0 = $("#ddl_store").val();
    obj.Item1 = ShowInVal.join(",");
    obj.Item2 = CategoryVal.join(",");;
    obj.Item3 = $("#ddl_status").val();    
    $("#tblProducts").DataTable({
        pageLength: $("#hid_PageDefaultEntry").val(),
        paging: true,
        searching: true,      
        info: true,
        ordering: false,
        order: [[0, "desc"]],       
        processing: false,
        serverSide: true,
        destroy: true,      
        ajax: {
            type: "POST",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            url: "DataTableService.asmx/LoadProducts",
            dataSrc: function (response) {  
                switch (response.rcode) {
                    case "0":
                        InfoPopup(response.rtitle, response.rmsg);
                        break;
                    case "1":
                        return response.data;
                        break;
                }                    
            },
            data: function (d) {
                return JSON.stringify({ parameters: d, reqObj: obj });
            }
        }
    });
}

//function LoadProductGrid() {

//    var ShowInVal = [];
//    $("#ddl_showin_filter :selected").each(function (i, selected) {
//        ShowInVal[i] = $(selected).val();
//    });

//    var CategoryVal = [];
//    $("#ddl_category_filter :selected").each(function (i, selected) {
//        CategoryVal[i] = $(selected).val();
//    });

//    var obj = {};
//    obj.Item0 = $("#ddl_store").val();
//    obj.Item1 = ShowInVal.join(",");
//    obj.Item2 = CategoryVal.join(",");;
//    obj.Item3 = $("#ddl_status").val();
//    $.ajax({
//        type: "POST",
//        url: "../api/HSD/LoadProductGrid",
//        data: JSON.stringify(obj),
//        contentType: "application/json; charset=utf-8",
//        dataType: "JSON",
//        success: OnSuccessLoadProductGrid,
//        failure: function (response) {
//            //alert(response.d);
//        },
//        error: function (response) {
//            //alert(response.d);
//        }
//    });
//}

//function OnSuccessLoadProductGrid(response) {
//    switch (response.rcode) {
//        case "0":
//            InfoPopup(response.rtitle, response.rmsg);
//            break;
//        case "1":            
//            $("#div_Product_Grid").html(response.Item0);
//            $("#tblProducts").DataTable({
//                "pageLength": 10,
//                "paging": true,
//                "searching": true,
//                "ordering": false,
//                "info": true
//            });
//            break;
//    }
//}


function LoadStore() {
    var obj = {};    
    $.ajax({
        type: "POST",
        url: "../api/HSD/LoadStore",
        data: JSON.stringify(obj),
        contentType: "application/json; charset=utf-8",
        dataType: "JSON",
        success: OnSuccessLoadStore,
        failure: function (response) {
            //alert(response.d);
        },
        error: function (response) {
            //alert(response.d);
        }
    });
}

function OnSuccessLoadStore(data) {
    PopulateControl(data, $("#ddl_store"));
    PopulateControl(data, $("#ddl_mdl_store"));
    LoadShowInFilter();
    LoadShowIn();
}

function PopulateControl(list, control) { 
    if (list.length > 0) {
        control.empty();
        $.each(list, function (key, value) {           
            control.append($('<option>', { value: value.ID, text: value.Name }));
        });
    }
}

/*-------------PRODUCT PAGE END-------------*/


/*-------------ADMIN PROFILE-------------*/

function CloseProfileModal() {
    $("li").removeClass("active");
    $("#Modal_Profile").modal("hide");
}

function SessionOutPopup(title, msg) {
    swal({
        title: title,
        text: msg,
        type: "warning",
        showCancelButton: false,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "OK",
        cancelButtonText: "Close",
        closeOnConfirm: true,
        closeOnCancel: true
    },
                function (isConfirm) {
                    if (isConfirm) {                       
                        $(location).attr("href", "logout.aspx");
                    }
                });
}

function SaveProfile() {
    var entriesok = true;
    var txtbxs;
    txtbxs = ["txt_FirstName", "tx_LastName", "txt_email", "txt_username", "txt_Password"];
    if (!validateTxtBxs(txtbxs)) {
        entriesok = false;
    }

    txtbxs = ["txt_email"];
    if (!validateEmail(txtbxs)) {
        entriesok = false;
    }
    if (entriesok) {
        if (entriesok) {
            var obj = {};
            obj.Item0 = $("#txt_FirstName").val();
            obj.Item1 = $("#tx_LastName").val();
            obj.Item2 = $("#txt_email").val();
            obj.Item3 = $("#txt_username").val();
            obj.Item4 = $("#txt_Password").val();
            $.ajax({
                type: "POST",
                url: "../api/HSD/SaveProfile",
                data: JSON.stringify(obj),
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                success: OnSuccessSaveProfile,
                failure: function (response) {
                    //alert(response.d);
                },
                error: function (response) {
                    //alert(response.d);
                }
            });
        }
    }
}

function OnSuccessSaveProfile(response) {    
    switch (response.rcode) {
        case "0":
            InfoPopup(response.rtitle, response.rmsg);
            break;
        case "1":
            SuccessPopup(response.rtitle, response.rmsg);
            CloseProfileModal();
            break;
    }
}

function LoadProfileDetails() {
    var obj = {};
    $.ajax({
        type: "POST",
        url: "../api/HSD/LoadProfileDetails",
        data: JSON.stringify(obj),
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: OnSuccessLoadProfileDetails,
        failure: function (response) {
            //alert(response.d);
        },
        error: function (response) {
            //alert(response.d);
        }
    });
}

function OnSuccessLoadProfileDetails(response) {
    switch (response.rcode) {
        case "0":
            InfoPopup(response.rtitle, response.rmsg);
            break;
        case "1":
            $("#txt_FirstName").css("background", "#FFFFFF");
            $("#tx_LastName").css("background", "#FFFFFF");
            $("#txt_email").css("background", "#FFFFFF");
            $("#txt_username").css("background", "#FFFFFF");
            $("#txt_Password").css("background", "#FFFFFF");
            $("#txt_FirstName").val(response.Item0);
            $("#tx_LastName").val(response.Item1);
            $("#txt_email").val(response.Item2);
            $("#txt_username").val(response.Item3);
            $("#txt_Password").val(response.Item4);
            $("#Modal_Profile").modal("show");
            $("li").removeClass("active");
            $("#nav_right").toggleClass("active");
            $("#nav_profile").toggleClass("active");
            break;
    }
}

/*-------------ADMIN PROFILE END-------------*/


/*-------------ADMIN LOGIN-------------*/

function LoginDefault()
{
    var obj = {};
    $.ajax({
        type: "POST",
        url: "api/HSD/LoginDefault",
        data: JSON.stringify(obj),
        contentType: "application/json; charset=utf-8",
        dataType: "JSON",
        success: OnSuccessLoginDefault,
        failure: function (response) {
            //alert(response.d);
        },
        error: function (response) {
            //alert(response.d);
        }
    });
}

function OnSuccessLoginDefault(response) {    
    switch (response.rcode) {
        case "0":
            $("#txt_userName").val("");
            $("#txt_Password").val("");
            $("#chk_rememberme").prop("checked", false);
            break;
        case "1":
            $("#txt_userName").val(response.Item0);
            $("#txt_Password").val(response.Item1);
            $("#chk_rememberme").prop("checked", true);
            break;
    }
    ShowLogin();
}

function ValidateAdminLogin() {
    var entriesok = true;
    //---Textboxes------
    var txtbxs = ["txt_userName", "txt_Password"];
    if (!validateTxtBxs(txtbxs)) {
        entriesok = false;
    }

    if (entriesok) {
        var obj = {};
        obj.Item0 = $("#txt_userName").val();
        obj.Item1 = $("#txt_Password").val();
        obj.Item2 = "0";
        if ($("#chk_rememberme").is(":checked")) {
            obj.Item2 = "1";
        }
        $.ajax({
            type: "POST",
            url: "api/HSD/AdminLogin",
            data: JSON.stringify(obj),
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: OnSuccessAdminLogin,
            failure: function (response) {
                //alert(response.d);
            },
            error: function (response) {
                //alert(response.d);
            }
        }); return false;
    }
    else {
        return entriesok;
    }
}

function OnSuccessAdminLogin(response) {
        switch (response.rcode) {
            case "0":
                ShowAdminLoginModelAfterLoad();
                show_box_Admin('3');
                InfoPopupAdmin(response.rtitle, response.rmsg, '2');
                break;
            case "1":
                url = "admin/home.aspx";
                $(location).attr("href", url);
                break;
        }
    }

function ShowAdminLoginModelAfterLoad() {
        $("#Modal_AdminLogin").modal("show");
        $("#div_LoginArea").show();
    }

function ShowLogin() {
        $("#div_LoginArea").show();
        show_box_Admin('2');
        $("#Modal_AdminLogin").modal("show");
    }

function InfoPopupAdmin(title, msg, boxid) {
        if (title == "")
            title = "Warning";
        $("#lbl_messagetitle").html(title);
        $("#lbl_messagecontent").html(msg);
        $(".confirm").click(function () {
            if (boxid == '2') {
                show_box_Admin(2);
            }
            else if (boxid == '1') {
                show_box_Admin(1);
            }
            return false;
        });

        return false;
    }

function SuccessPopupAdmin(title, msg, boxid) {
        if (title == "")
            title = "Success";
        $("#lbl_messagetitle").html(title);
        $("#lbl_messagecontent").html(msg);

        $(".confirm").click(function () {
            if (boxid == '1') {
                show_box_Admin(1);
            }
            return false;
        });
        return false;
    }

function SuccessPopupAdmin2(title, msg) {
        if (title == "")
            title = "Success";
        swal({
            title: title,
            text: msg,
            html: true,
            type: "success"
        }); return false;
    }

function ErrorPopupAdmin(msg) {
        swal({
            title: "Vista Shift",
            text: msg,
            type: "error"
        }); return false;
    }

function CloseAdminLoginModal() {
        ClearAdminLoginFields();
        $("#div_LoginArea").hide();
        $("#div_message").hide();
        $("#Modal_AdminLogin").modal("hide");
    }

function show_box_Admin(id) {
        $("#div_LoginArea").hide();
        $("#div_login").hide();
        $("#div_forgotlogin").hide();
        $("#div_message").hide();
        if (id == 1) {
            ClearAdminLoginFields();
            $("#div_LoginArea").show();
            $("#div_forgotlogin").show();
            $("#txt_ForgotEmail").focus();
        }
        else if (id == 2) {
            ClearAdminLoginFields();
            $("#div_LoginArea").show();
            $("#div_login").show();
            $("#txt_userName").focus();
        }
        else if (id == 3) {
            ClearAdminLoginFields();
            $("#div_message").show();
            $("#txt_userName").focus();
        }
    }

function ClearAdminLoginFields() {
        if (!$("#chk_rememberme").is(":checked")) {
            $("#txt_userName").val("");
            $("#txt_Password").val("");
        }
        $("#txt_ForgotEmail").val("");
        $("#txt_userName").css("background", "#FFFFFF");
        $("#txt_Password").css("background", "#FFFFFF");
        $("#txt_ForgotEmail").css("background", "#FFFFFF");
    }

function HideCreateAdminAccountModel() {
        $("#Modal_AdminLogin").modal("show");
        $("#div_LoginArea").hide();
        $("#div_message").show();
        //ClearCreateAccount();
    }

function ValidateAdminRetrieve() {
        var entriesok = true;
        //---Textboxes------
        var txtbxs = ["txt_ForgotEmail"];
        if (!validateEmail(txtbxs)) {
            entriesok = false;
        }
        if (entriesok) {

            var obj = {};
            obj.emailaddress = $("#txt_ForgotEmail").val();
            $.ajax({
                type: "POST",
                url: "TTLService.asmx/RetrievePassword",
                data: JSON.stringify(obj),
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                success: OnSuccessAdminRetrievePassword,
                failure: function (response) {
                    //alert(response.d);
                },
                error: function (response) {
                    //alert(response.d);
                }
            }); return false;
        }
        else {
            return entriesok;
        }
    }

function OnSuccessAdminRetrievePassword(response) {
        var value = jQuery.parseJSON(response.d);
        ShowAdminLoginModelAfterLoad();
        //show_box_Admin(1);
        show_box_Admin(3);
        switch (value.responseCode) {
            case "0":
                InfoPopupAdmin(value.messageTitle, value.message, '1');
                break;
            case "1":
                $("#Modal_AdminLogin").modal("hide");
                SuccessPopupAdmin2(value.messageTitle, value.message);
                break;
        }
    }

/*-------------ADMIN LOGIN END-------------*/


/*------------------------------PRODUCTS PAGE----------------*/
var HSDSearchItem = "";
var HSDSearchVal = "";
var HSDSortVal = "1";
var HSDPageNum = "1";
var HSDPageLimit = "5";

$(window).scroll(function () {    
    //---------------FOR SCROLL IN CHROME MOBILE-------------
    if ($(window).width() < 415) {
        if ($(window).scrollTop() == document.body.clientHeight - window.innerHeight) {
            if ($("#hid_scrollEnd").val() == "no") {
                LoadMore(); 
            }
        }
    }
    else {
        if ($(window).scrollTop() == $(document).height() - $(window).height()) {
            if ($("#hid_scrollEnd").val() == "no") {
                alert("hai 11");
                LoadMore();
            }
        }
    }
});

//----------------SEARCH PRODUCTS---------------

$("#txt_search").keypress(function (event) {
    var keycode = (event.keyCode ? event.keyCode : event.which);
    if (keycode == "13") {
        SearchThisProducts(); return false;
    }
});

function SearchThisProducts() {
    $("#btn_sortItem.btn-sort").html("<span class=\"glyphicon glyphicon-sort\"></span><span class=\"label-icon\">&nbsp;Sort by&nbsp;</span><span class=\"caret\"></span>");
    HSDSortVal = "1";
    var searchItem = $("#div_searchItem").find(".btn-search").find(".label-icon").html();
    $("#div_submenu1.scrollmenu a").css("background-color", "");
    if (searchItem == "Search" || searchItem == "&nbsp;Search&nbsp;")
        searchItem = "All";
    $("#hid_searchItem").val(searchItem);
    var entriesok = true;
    //---Textboxes------    
    var txtbxs = ["txt_search"];
    if (!validateTxtBxs(txtbxs)) {
        entriesok = false;
    }
    HSDSearchVal = $.trim($("#txt_search").val());

    if (entriesok) {
        SearchProducts();
    }
    else {
        if (searchItem != "Search" && searchItem != "&nbsp;Search&nbsp;" && searchItem != "All") {
            HSDSearchVal = searchItem;
            SearchProducts();
        }
    }
}

function SearchProducts() {
    $(".se-pre-con").show();
    $(".se-pre-con").center();
    $("#div_products").html("");
    $("#div_sortItem").hide();
    HSDPageNum = "1";
    HSDSearchItem = $("#hid_searchItem").val();
    if (HSDSearchItem != "" && HSDSearchItem != "Search" && HSDSearchItem != "All") {
        HSDPageLimit = "10";
    }
    else {
        HSDPageLimit = "5";
    }
    if ($.trim(HSDSearchVal) == "") {
        $("#div_submenu1.scrollmenu a").css("background-color", "");
        $("#txt_search").val("");
    }
    $("#txt_search").css("background", "#FFFFFF");
    //$("#div_loadMore").hide(); 
    $("#hid_scrollEnd").val("yes");
    switch ("1") {
        case "1"://STORE AMAZONE
            SearchAmazon();
            break;
    }
    return false;
}

function SearchAmazon() {
    /*Sort
    1 - Relevence ASC
    2 - Popular ASC
    3 - Price ASC
    4 - Price DESC
    5 - Review ASC
    */
    var obj = {};
    obj.Item0 = $.trim(HSDSearchItem);
    obj.Item1 = $.trim(HSDSearchVal);
    obj.Item2 = HSDPageNum;
    obj.Item3 = HSDSortVal;
    //alert("Search Item: " + obj.Item0);
    //alert("Search Val: " + obj.Item1);
    //alert("Page Num: " + obj.Item2);
    //alert("Sort Val: " + obj.Item3);

    $.ajax({
        type: "POST",
        url: "api/Amazon/Search",
        data: JSON.stringify(obj),
        contentType: "application/json; charset=utf-8",
        dataType: "JSON",
        success: OnSuccessSearchAmazon,
        failure: function (response) {
            //alert(response.d);
        },
        error: function (response) {
            //alert(response.d);
        }
    });
}

function OnSuccessSearchAmazon(response) {

    if (response.rcode == null)
        LoadMore();
    switch (response.rcode) {
        case "0":
            InfoPopup(response.rtitle, response.rmsg);
            break;
        case "1":
            var TotalHSDPageNum = "1"
            if (response.Item1 != "") {
                if (parseInt(response.Item1) > parseInt(HSDPageLimit)) {
                    TotalHSDPageNum = parseInt(HSDPageLimit);
                }
                else {
                    TotalHSDPageNum = response.Item1;
                }
            }
            if (parseInt(TotalHSDPageNum) > HSDPageNum) {
                HSDPageNum = parseInt(HSDPageNum) + 1;
                //$("#div_loadMore").show();
                $("#hid_scrollEnd").val("no");
            }
            else {
                //$("#div_loadMore").hide();
                $("#hid_scrollEnd").val("yes");
            }
            $("#div_sortItem").show();
            $("#div_products").append(response.Item0);
            $(".se-pre-con").hide();
            break;
    }
}

function LoadMore() {

    $(".se-pre-con").show();
    $(".se-pre-con").center();

    var obj = {};
    obj.Item0 = $.trim(HSDSearchItem);
    obj.Item1 = $.trim(HSDSearchVal);
    obj.Item2 = HSDPageNum;
    obj.Item3 = HSDSortVal;
    //alert("Search Item: " + obj.Item0);
    //alert("Search Val: " + obj.Item1);
    //alert("Page Num: " + obj.Item2);
    //alert("Sort Val: " + obj.Item3);

    //alert(HSDPageLimit);
    $.ajax({
        type: "POST",
        url: "api/Amazon/Search",
        data: JSON.stringify(obj),
        contentType: "application/json; charset=utf-8",
        dataType: "JSON",
        success: OnSuccessSearchAmazon,
        failure: function (response) {
            //alert(response.d);
        },
        error: function (response) {
            //alert(response.d);
        }
    });
}

function OnSuccessSearchAmazon(response) {
    if (response.rcode == null)
        LoadMore();
    switch (response.rcode) {
        case "0":
            InfoPopup(response.rtitle, response.rmsg);
            break;
        case "1":
            var TotalHSDPageNum = "1"

            if (response.Item1 != "") {
                if (parseInt(response.Item1) > parseInt(HSDPageLimit)) {
                    TotalHSDPageNum = parseInt(HSDPageLimit);
                }
                else {
                    TotalHSDPageNum = response.Item1;
                }
            }
            if (parseInt(TotalHSDPageNum) > HSDPageNum) {
                HSDPageNum = parseInt(HSDPageNum) + 1;
                //$("#div_loadMore").show();
                $("#hid_scrollEnd").val("no");
            }
            else {
                //$("#div_loadMore").hide();
                $("#hid_scrollEnd").val("yes");
            }
            $("#div_sortItem").show();
            $("#div_products").append(response.Item0);
            $(".se-pre-con").hide();
            break;
    }
}

//----------------END SEARCH PRODUCTS-----------        

/*---------SORT ITEM--------*/

$(function () {
    $("#div_sortItem .dropdown-menu li a").click(function () {

        var selText = $(this).html();
        //working version - for single button //
        //$('.btn:first-child').html(selText+'<span class="caret"></span>');  
        //working version - for multiple buttons //
        $(this).parents("#div_sortItem").find(".btn-sort").html(selText);
        $("#hid_sortVal").val(($(this).parents("#div_sortItem").find(".btn-sort").find(".label-icon").html()));


        switch ($("#hid_sortVal").val()) {
            case "Relevance":
                HSDSortVal = "1";
                SearchProducts();
                break;

            case "New &amp; Popular":
                HSDSortVal = "2";
                SearchProducts();
                break;

            case "Price: Low to High":
                HSDSortVal = "3";
                SearchProducts();
                break;

            case "Price: High to Low":
                HSDSortVal = "4";
                SearchProducts();
                break;

            case "Avg. Customer Review":
                HSDSortVal = "5";
                SearchProducts();
                break;

            case "Newest Arrivals":
                HSDSortVal = "6";
                SearchProducts();
                break;

            default:
                HSDSortVal = "1";
                SearchProducts();
                break;
        }

    });
});

/*---------------MENU PAGE SCRIPTS-------------*/

$(function () {
    $("#div_searchItem .dropdown-menu li a").click(function () {
        var selText = $(this).html();
        //working version - for single button //
        //$('.btn:first-child').html(selText+'<span class="caret"></span>');  
        //working version - for multiple buttons //
        $(this).parents("#div_searchItem").find(".btn-search").html(selText);
        $("#hid_searchItem").val(($(this).parents("#div_searchItem").find(".btn-search").find(".label-icon").html()));
        //alert($("#hid_searchItem").val());
    });
});

function MenuClick(id) {
    $("#txt_search").val("");
    $("#btn_searchItem.btn-search").html("<span class=\"glyphicon glyphicon-search\"></span><span class=\"label-icon\">&nbsp;Search&nbsp;</span><span class=\"caret\"></span>");
    $("#btn_sortItem.btn-sort").html("<span class=\"glyphicon glyphicon-sort\"></span><span class=\"label-icon\">&nbsp;Sort by&nbsp;</span><span class=\"caret\"></span>");
    $("#div_submenu1.scrollmenu a").css("background-color", "");
    $("#div_submenu1.scrollmenu a#m_" + id).css("background-color", "#777");
    HSDSortVal = "1";
    switch (id) {
        case "0"://TODAY'S DEALS            
            $("#hid_searchItem").val("All");
            HSDSearchVal = "prime-deals";
            SearchProducts();
            break;

        case "1"://WHAT'S NEW            
            $("#hid_searchItem").val("All");
            HSDSearchVal = "new-releases";
            SearchProducts();
            break;

        case "2"://MEN'S FASHION                        
            $("#hid_searchItem").val("Apparel");
            HSDSearchVal = "men-fashion";
            SearchProducts();
            break;

        case "3"://GIFTS FOR WOMEN
            $("#hid_searchItem").val("Apparel");
            HSDSearchVal = "womens-fashion";
            SearchProducts();
            break;

        case "4"://GIFTS FOR KIDS            
            $("#hid_searchItem").val("Baby");
            HSDSearchVal = "kids-fashion";
            SearchProducts();

            break;

        case "5"://BAGS & LUGGAGE            
            $("#hid_searchItem").val("All");
            HSDSearchVal = "Luggage-Bags";
            SearchProducts();
            break;

        case "6"://GEAR & GADGETS            
            $("#hid_searchItem").val("All");
            HSDSearchVal = "latest-in-technology-gadgets";
            SearchProducts();
            break;

        case "7"://HOME & OFFICE GIFTS            
            $("#hid_searchItem").val("All");
            HSDSearchVal = "Gifts-Store";
            SearchProducts();
            break;

        case "8"://WEARABLE            
            $("#hid_searchItem").val("All");
            HSDSearchVal = "Wearable-Technology";
            SearchProducts();
            break;

        case "9"://GEEKY STUFF            
            $("#hid_searchItem").val("All");
            HSDSearchVal = "geek-stuff";
            SearchProducts();
            break;

        case "10"://FOOD & DRINK            
            $("#hid_searchItem").val("All");
            HSDSearchVal = "Food-Drink";
            SearchProducts();
            break;

        case "11"://TOYS & GAMES            
            $("#hid_searchItem").val("Toys");
            HSDSearchVal = "Toys-Games";
            SearchProducts();
            break;

        case "12"://RANDOM           
            $("#hid_searchItem").val("All");
            HSDSearchVal = "Random-Item";
            SearchProducts();
            break;
    }
}

/*-------------------MASTERPAGE SCRIPTS---------*/

jQuery.fn.center = function () {
    this.css("position", "fixed");
    this.css("top", ($(window).height() / 2) - (this.outerHeight() / 2));
    this.css("left", ($(window).width() / 2) - (this.outerWidth() / 2));
    return this;
}

$(document).ready(function () {
    //-----------MIN SCREEN HEIGHT------
    var clientHeight = document.documentElement.clientHeight;
    var clientWidth = document.documentElement.clientWidth;
    if (clientWidth < 760) {
        clientHeight = clientHeight - 200;
        $('#wrapper1').css('min-height', clientHeight + 'px');
    }
    else {
        clientHeight = clientHeight - 220;
        $('#wrapper1').css('min-height', clientHeight + 'px');
    }
    //----------------------------------   

    //------------SCROLE TOP------------------
    $(window).scroll(function () {
        if ($(this).scrollTop() > 100) {
            $('.scrollup').fadeIn();

        } else {
            $('.scrollup').fadeOut();
        }

    });
    $('.scrollup').click(function () {
        $("html, body").animate({ scrollTop: 0 }, 600);
        return false;
    });
    //-------------------------------------------------
});

//$(document).ajaxStart(function () {
//    $(".se-pre-con").show();
//    $(".se-pre-con").center();
//});

//$(document).ajaxComplete(function () {
//    $(".se-pre-con").hide();
//});


