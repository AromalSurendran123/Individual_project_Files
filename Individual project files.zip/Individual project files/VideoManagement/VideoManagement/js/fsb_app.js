
/*---------------THIS IS FOR CLOSING ONE MODEL AND OPENING OTHER MODEL ISSUE FIX----------------*/
$('.modal').on("hidden.bs.modal", function (e) {
    if ($('.modal:visible').length) {
        $('.modal-backdrop').first().css('z-index', parseInt($('.modal:visible').last().css('z-index')) - 10);
        $('body').addClass('modal-open');
    }
}).on("show.bs.modal", function (e) {
    if ($('.modal:visible').length) {
        $('.modal-backdrop.in').first().css('z-index', parseInt($('.modal:visible').last().css('z-index')) + 10);
        $(this).css('z-index', parseInt($('.modal-backdrop.in').first().css('z-index')) + 10);
    }
});
/*---------------END----------------------*/

//----------------GET SHORT URL---------------
function GetShortURL() {


    var entriesok = true;
    //---Textboxes------    
    var txtbxs = ["txt_LoangUrl"];
    if (!validateTxtBxs(txtbxs)) {
        entriesok = false;
    }

    if (entriesok) {

        var obj = {};
        obj.Item0 = $("#txt_LoangUrl").val();
        $.ajax({
            type: "POST",
            url: "api/FSB/GetShortURL",
            data: JSON.stringify(obj),
            contentType: "application/json; charset=utf-8",
            dataType: "JSON",
            success: OnSuccessGetShortURL,
            failure: function (response) {
                //alert(response.d);
            },
            error: function (response) {
                //alert(response.d);
            }
        });
    }
}

function OnSuccessGetShortURL(response) {
    switch (response.rcode) {
        case "0":
            InfoPopup(response.rtitle, response.rmsg);
            break;
        case "1":
            $("#txt_LoangUrl").val("");
            $("#div_shortUrl").html(response.Item0);
            break;
    }
}
//----------------END---------------

/*-------------SUBMIT CONTACT US PAGE-------------*/
function SubmitContactUs() {
    var entriesok = true;
    //---Textboxes------
    var txtbxs = ["txt_ContactName", "txt_ContactEmail", "txt_ContactMessage"];
    if (!validateTxtBxs(txtbxs)) {
        entriesok = false;
    }
    txtbxs = ["txt_ContactEmail"];
    if (!validateEmail(txtbxs)) {
        entriesok = false;
    }

    if ($("#hid_validate_capcha_contactus").val() == "") {
        entriesok = false;
        InfoPopup("Validate Captcha", "Please check i'm not a robot.");
    }

    if (entriesok) {
        var obj = {};
        obj.Item0 = $("#ddl_ContactSubject option:selected").text();
        obj.Item1 = $("#txt_ContactName").val();
        obj.Item2 = $("#txt_ContactEmail").val();
        obj.Item3 = $("#txt_ContactMessage").val();
        obj.Item4 = $("#hid_validate_capcha_contactus").val();
        $.ajax({
            type: "POST",
            url: "api/FSB/SubmitContactUs",
            data: JSON.stringify(obj),
            contentType: "application/json; charset=utf-8",
            dataType: "JSON",
            success: OnSuccessSubmitContactUs,
            failure: function (response) {
                //alert(response.d);
            },
            error: function (response) {
                //alert(response.d);
            }
        });
    }
}
function OnSuccessSubmitContactUs(response) {
    switch (response.rcode) {
        case "0":
            InfoPopup(response.rtitle, response.rmsg);
            break;
        case "1":
            SuccessPopupWithRedirection(response.rtitle, response.rmsg, "contactus");
            break;
    }
}
/*-------------END-----------------*/
















/*-------------SUBMIT A PRODUCT PAGE-------------*/
function SubmitAProduct() {
    var entriesok = true;
    //---Textboxes------
    var txtbxs = ["txt_ProdctTitle", "txt_ProductLink", "txt_ProductSubmitEmail"];
    if (!validateTxtBxs(txtbxs)) {
        entriesok = false;
    }
    txtbxs = ["txt_ProductSubmitEmail"];
    if (!validateEmail(txtbxs)) {
        entriesok = false;
    }

    if ($("#hid_validate_capcha_product_submit").val() == "") {
        entriesok = false;
        InfoPopup("Validate Captcha", "Please check i'm not a robot.");
    }

    if (entriesok) {
        var obj = {};
        obj.Item0 = $("#txt_ProdctTitle").val();
        obj.Item1 = $("#txt_ProductLink").val();
        obj.Item2 = $("#txt_ProductSubmitEmail").val();
        obj.Item3 = $("#hid_validate_capcha_product_submit").val();
        $.ajax({
            type: "POST",
            url: "api/FSB/SubmitAProduct",
            data: JSON.stringify(obj),
            contentType: "application/json; charset=utf-8",
            dataType: "JSON",
            success: OnSuccessSubmitAProduct,
            failure: function (response) {
                //alert(response.d);
            },
            error: function (response) {
                //alert(response.d);
            }
        });
    }
}
function OnSuccessSubmitAProduct(response) {
    switch (response.rcode) {
        case "0":
            InfoPopup(response.rtitle, response.rmsg);
            break;
        case "1":            
            SuccessPopupWithRedirection(response.rtitle, response.rmsg,"submitaproduct");
            break;
    }
}
/*-------------END-----------------*/

/*-------------REMOVE FROM WISHLIST-------------*/
function RemoveFromWishlist(PrdID) {
    var obj = {};
    $("#hid_productId").val(PrdID);
    obj.Item0 = PrdID;
    $.ajax({
        type: "POST",
        url: "api/FSB/UnSaveWishlist",
        data: JSON.stringify(obj),
        contentType: "application/json; charset=utf-8",
        dataType: "JSON",
        success: OnSuccessRemoveFromWishlist,
        failure: function (response) {
            //alert(response.d);
        },
        error: function (response) {
            //alert(response.d);
        }
    });
}
function OnSuccessRemoveFromWishlist(response) {
    switch (response.rcode) {
        case "0":
            InfoPopup(response.rtitle, response.rmsg);
            break;
        case "1":
            $("#hid_upperLimit").val("12");
            $("#hid_wiat").val("1");
            $("#hid_scrollEnd").val("NO");
            $("#div_products").html("");
            LoadWishList();
            break;
    }
}
/*-------------LOAD WISHLIST-------------*/
function LoadWishList() {    
    if ($("#hid_upperLimit").val() != "0" && $("#hid_upperLimit").val() != "" && $("#hid_scrollEnd").val() != "YES" && $("#hid_wiat").val() != "0") {        
        $(".se-pre-con").show();
        $(".se-pre-con").center();
        $("#hid_wiat").val("0");
        var obj = {};        
        obj.Item0 = $("#txt_search").val();        
        obj.l_Limit = $("#hid_lowerLimit").val();
        obj.u_Limit = $("#hid_upperLimit").val();
        obj.rowCount = "5";
        
        $.ajax({
            type: "POST",
            url: "api/FSB/LoadWishList",
            data: JSON.stringify(obj),
            contentType: "application/json; charset=utf-8",
            dataType: "JSON",
            success: OnSuccessLoadWishList,
            failure: function (response) {
                //alert(response.d);
            },
            error: function (response) {
                //alert(response.d);
            }
        });
    }
}

function OnSuccessLoadWishList(response) {
    switch (response.rcode) {
        case "0":
            InfoPopup(response.rtitle, response.rmsg);
            break;
        case "1":
            $("#hid_lowerLimit").val(response.l_Limit);
            $("#hid_upperLimit").val(response.u_Limit);            
            $("#hid_scrollEnd").val(response.Item1)
            $("#div_products").append(response.Item0);
            $("#hid_wiat").val("1");
            setTimeout(function () {
                $(".se-pre-con").hide();
            }, 500);
            break;
    }
}


/*-------------SAVE MY SETTINGS-------------*/
function SaveMySettings() {
    var entriesok = true;
    //---Textboxes------
    var txtbxs = ["txt_ProfileEmail", "txt_ProfilePassword", "txt_OldProfilePassword", "txt_ProfilePasswordConfirm"];
    if (!validateTxtBxs(txtbxs)) {
        entriesok = false;
    }
    if (!validateConfirmFields("txt_ProfilePassword", "txt_ProfilePasswordConfirm"))
    {
        entriesok = false;
    }
    if (entriesok) {
        var obj = {};
        obj.Item0 = $("#txt_ProfileEmail").val();
        obj.Item1 = $("#txt_ProfilePassword").val();
        obj.Item2 = $("#txt_ProfilePasswordConfirm").val();
        obj.Item3 = $("#txt_OldProfilePassword").val();
        $.ajax({
            type: "POST",
            url: "api/FSB/SaveMySettings",
            data: JSON.stringify(obj),
            contentType: "application/json; charset=utf-8",
            dataType: "JSON",
            success: OnSuccessSaveMySettings,
            failure: function (response) {
                //alert(response.d);
            },
            error: function (response) {
                //alert(response.d);
            }
        });
    }
}
function OnSuccessSaveMySettings(response) {
    switch (response.rcode) {
        case "0":
            InfoPopup(response.rtitle, response.rmsg);
            break;
        case "1":            
            $("#Modl_MySettings").modal("hide");
            SuccessPopup(response.rtitle, response.rmsg);
            break;
    }
}

/*-------------LOAD MY SETTINGS-------------*/
function LoadMySettings() {    
    var obj = {};       
    $.ajax({
        type: "POST",
        url: "api/FSB/LoadMySettings",
        data: JSON.stringify(obj),
        contentType: "application/json; charset=utf-8",
        dataType: "JSON",
        success: OnSuccessLoadMySettings,
        failure: function (response) {
            //alert(response.d);
        },
        error: function (response) {
            //alert(response.d);
        }
    });
}

function OnSuccessLoadMySettings(response) {
    switch (response.rcode) {
        case "0":
            InfoPopup(response.rtitle, response.rmsg);
            break;
        case "1":
            $("#txt_ProfileEmail").val(response.Item0);
            $("#txt_OldProfilePassword").val("");
            $("#txt_ProfilePassword").val("");
            $("#txt_ProfilePasswordConfirm").val("");
            $("#txt_OldProfilePassword").css("background", "#FFFFFF");
            $("#txt_ProfileEmail").css("background", "#FFFFFF");
            $("#txt_ProfilePassword").css("background", "#FFFFFF");
            $("#Modl_MySettings").modal("show");            
            break;
    }
}
function CloseMySettingsModel() {
    $("#txt_ProfileEmail").val("");
    $("#txt_ProfilePassword").val("");
    $("#txt_ProfilePasswordConfirm").val("");
    $("#txt_ProfileEmail").css("background", "#FFFFFF");
    $("#txt_ProfilePassword").css("background", "#FFFFFF");
    $("#Modl_MySettings").modal("hide");
}
/*-------------SAVE OR UNSAVE TO WISH LIST-------------*/
function SaveWishlist(PrdID) {
    var obj = {};
    $("#hid_productId").val(PrdID);
    obj.Item0 = PrdID;
    $.ajax({
        type: "POST",
        url: "api/FSB/SaveWishlist",
        data: JSON.stringify(obj),
        contentType: "application/json; charset=utf-8",
        dataType: "JSON",
        success: OnSuccessSaveWishlist,
        failure: function (response) {
            //alert(response.d);
        },
        error: function (response) {
            //alert(response.d);
        }
    });
}
function OnSuccessSaveWishlist(response) {      
    switch (response.rcode) {
        case "0":
            InfoPopup(response.rtitle, response.rmsg);
            break;
        case "1":
            $("#a_save_" + +response.Item0).hide();
            $("#a_unsave_" + +response.Item0).show();
            $(".div_count_" + response.Item0).html(response.Item1);
            break;
    }    
}
function UnSaveWishlist(PrdID) {
    var obj = {};
    $("#hid_productId").val(PrdID);
    obj.Item0 = PrdID;
    $.ajax({
        type: "POST",
        url: "api/FSB/UnSaveWishlist",
        data: JSON.stringify(obj),
        contentType: "application/json; charset=utf-8",
        dataType: "JSON",
        success: OnSuccessUnSaveWishlist,
        failure: function (response) {
            //alert(response.d);
        },
        error: function (response) {
            //alert(response.d);
        }
    });
}
function OnSuccessUnSaveWishlist(response) {
    switch (response.rcode) {
        case "0":
            InfoPopup(response.rtitle, response.rmsg);
            break;
        case "1":
            $("#a_save_" + +response.Item0).show();
            $("#a_unsave_" + +response.Item0).hide();
            $(".div_count_" + response.Item0).html(response.Item1);
            break;
    }
}

/*-------------User Registration-------------*/
$("#txt_Email_Register").keypress(function (event) {
    var keycode = (event.keyCode ? event.keyCode : event.which);
    if (keycode == "13") {
        ValidateUserRegistration();
    }
});
$("#txt_Password_Register").keypress(function (event) {
    var keycode = (event.keyCode ? event.keyCode : event.which);
    if (keycode == "13") {
        ValidateUserRegistration();
    }
});
$("#txt_Password_Confirm_Register").keypress(function (event) {
    var keycode = (event.keyCode ? event.keyCode : event.which);
    if (keycode == "13") {
        ValidateUserRegistration();
    }
});
function LogoutUser() {
    var obj = {};    
    $.ajax({
        type: "POST",
        url: "api/FSB/LogoutUser",
        data: JSON.stringify(obj),
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: OnSuccessLogoutUser,
        failure: function (response) {
            //alert(response.d);
        },
        error: function (response) {
            //alert(response.d);
        }
    }); return false;

}

function OnSuccessLogoutUser(response) {
    switch (response.rcode) {
        case "0":
            InfoPopup(response.rtitle, response.rmsg);
            break;
        case "1":
            location.reload(true);
            break;
    }    
}

function ValidateUserRegistration() {
    var entriesok = true;
    //---Textboxes------
    var txtbxs = ["txt_Email_Register", "txt_Password_Register", "txt_Password_Confirm_Register"];
    if (!validateTxtBxs(txtbxs)) {
        entriesok = false;
    }

    txtbxs = ["txt_Email_Register"];
    if (!validateEmail(txtbxs)) {
        entriesok = false;
    }
   
    if (!validateConfirmFields("txt_Password_Register", "txt_Password_Confirm_Register")) {
        entriesok = false;
    }

    if ($("#hid_validatCapcha").val() == "") {
        entriesok = false;
        InfoPopup("Validate Captcha", "Please check i'm not a robot.");
    }

    if (entriesok) {
        var obj = {};
        obj.Item0 = $("#txt_Email_Register").val();
        obj.Item1 = $("#txt_Password_Register").val();
        obj.Item2 = $("#txt_Password_Confirm_Register").val();
        obj.Item3 = $("#hid_validatCapcha").val();
        $.ajax({
            type: "POST",
            url: "api/FSB/UserRegistration",
            data: JSON.stringify(obj),
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: OnSuccessUserRegistration,
            failure: function (response) {
                //alert(response.d);
            },
            error: function (response) {
                //alert(response.d);
            }
        }); return false;
    }
    else {
        return entriesok;
    }
}

function OnSuccessUserRegistration(response) {
    switch (response.rcode) {
        case "0":            
            InfoPopup(response.rtitle, response.rmsg);
            break;
        case "1":
            location.reload(true);
            break;
    }
}

function ShowRegisterModal() {    
    $("#txt_Email_Register").val("");
    $("#txt_Password_Register").val("");
    $("#txt_Password_Confirm_Register").val("");
    $("#txt_Email_Register").css("background", "#FFFFFF");
    $("#txt_Password_Register").css("background", "#FFFFFF");
    $("#txt_Password_Confirm_Register").css("background", "#FFFFFF");
    $("#Modal_UserRegister").modal("show");    
}

function CloseRegisterModal() {    
    $("#Modal_UserRegister").modal("hide");
    $("body").removeAttr("style");
}


function DeleteAccount(id) {
    swal({
        title: "",
        text: "Are you sure to delete your account with COREMETRICS TECHNOLOGIES PRIVATE LIMITED?",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "Yes, delete it!",
        cancelButtonText: "No, keep it!",
        closeOnConfirm: false,
        closeOnCancel: false
    },
            function (isConfirm) {
                if (isConfirm) {
                    var obj = {};
                    obj.Item0 = id;
                    $.ajax({
                        type: "POST",
                        url: "api/FSB/DeleteAccount",
                        data: JSON.stringify(obj),
                        contentType: "application/json; charset=utf-8",
                        dataType: "json",
                        success: OnSuccessDeleteAccount,
                        failure: function (response) {
                            //alert(response.d);
                        },
                        error: function (response) {
                            //alert(response.d);
                        }
                    });
                } else {
                    swal("Cancelled", "", "error");
                }
            });
}
function OnSuccessDeleteAccount(response) {
    switch (response.rcode) {
        case "0":
            InfoPopup(response.rtitle, response.rmsg);
            break;
        case "1":
            $(location).attr("href", "logout.aspx");
            break;
    }
}


/*-------------User Registration End-------------*/

/*-------------User LOGIN-------------*/

$("#txt_Email").keypress(function (event) {
    var keycode = (event.keyCode ? event.keyCode : event.which);
    if (keycode == "13") {
        ValidateUserLogin();
    }
});

$("#txt_Password").keypress(function (event) {
    var keycode = (event.keyCode ? event.keyCode : event.which);
    if (keycode == "13") {
        ValidateUserLogin();
    }
});

$("#txt_ForgotEmail").keypress(function (event) {
    var keycode = (event.keyCode ? event.keyCode : event.which);
    if (keycode == "13") {
        ValidateUserRetrieve();
    }
});

function LoginDefault() {
    var obj = {};
    $.ajax({
        type: "POST",
        url: "api/FSB/LoginDefault",
        data: JSON.stringify(obj),
        contentType: "application/json; charset=utf-8",
        dataType: "JSON",
        success: OnSuccessLoginDefault,
        failure: function (response) {
            //alert(response.d);
        },
        error: function (response) {
            //alert(response.d);
        }
    });
}

function OnSuccessLoginDefault(response) {
    switch (response.rcode) {
        case "0":
            $("#txt_Email").val("");
            $("#txt_Password").val("");
            $("#txt_ForgotEmail").val("");
            $("#txt_Email").css("background", "#FFFFFF");
            $("#txt_Password").css("background", "#FFFFFF");
            $("#txt_ForgotEmail").css("background", "#FFFFFF");                            
            $("#chk_rememberme").prop("checked", false);              
            break;
        case "1":
            $("#txt_Email").val(response.Item0);
            $("#txt_Password").val(response.Item1);
            $("#chk_rememberme").prop("checked", true);
            break;
    }
    $("#div_LoginArea").show();
    show_box_User('2');
    $("#Modal_UserLogin").modal("show");
}

function ValidateUserLogin() {
    var entriesok = true;
    //---Textboxes------
    var txtbxs = ["txt_Email", "txt_Password"];
    if (!validateTxtBxs(txtbxs)) {
        entriesok = false;
    }
    txtbxs = ["txt_Email"];
    if (!validateEmail(txtbxs)) {
        entriesok = false;
    }
    if (entriesok) {
        var obj = {};
        obj.Item0 = $("#txt_Email").val();
        obj.Item1 = $("#txt_Password").val();
        obj.Item2 = "0";
        if ($("#chk_rememberme").is(":checked")) {
            obj.Item2 = "1";
        }
        $.ajax({
            type: "POST",
            url: "api/FSB/UserLogin",
            data: JSON.stringify(obj),
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: OnSuccessUserLogin,
            failure: function (response) {
                //alert(response.d);
            },
            error: function (response) {
                //alert(response.d);
            }
        }); return false;
    }
    else {
        return entriesok;
    }
}

function OnSuccessUserLogin(response) {
    switch (response.rcode) {
        case "0":
            ShowUserLoginModelAfterLoad();
            show_box_User('3');
            InfoPopupUser(response.rtitle, response.rmsg, '2');
            break;
        case "1":
            location.reload(true);
            break;
    }
}

function ShowUserLoginModelAfterLoad() {
    $("#Modal_UserLogin").modal("show");
    $("#div_LoginArea").show();
}

function InfoPopupUser(title, msg, boxid) {
    if (title == "")
        title = "Warning";
    $("#lbl_messagetitle").html(title);
    $("#lbl_messagecontent").html(msg);
    $(".confirm").click(function () {
        if (boxid == '2') {
            show_box_User(2);
        }
        else if (boxid == '1') {
            show_box_User(1);
        }
        return false;
    });

    return false;
}

function SuccessPopupUser(title, msg, boxid) {
    if (title == "")
        title = "Success";
    $("#lbl_messagetitle").html(title);
    $("#lbl_messagecontent").html(msg);

    $(".confirm").click(function () {
        if (boxid == '1') {
            show_box_User(1);
        }
        return false;
    });
    return false;
}

function SuccessPopupUser2(title, msg) {
    if (title == "")
        title = "Success";
    swal({
        title: title,
        text: msg,
        html: true,
        type: "success"
    }); return false;
}

function ErrorPopupUser(msg) {
    swal({
        title: "Vista Shift",
        text: msg,
        type: "error"
    }); return false;
}

function CloseUserLoginModal() {
    ClearUserLoginFields();
    $("#div_LoginArea").hide();
    $("#div_message").hide();    
    $("#Modal_UserLogin").modal("hide");
    $("body").removeAttr("style");
}

function show_box_User(id) {
    $("#div_LoginArea").hide();
    $("#div_login").hide();
    $("#div_forgotlogin").hide();
    $("#div_message").hide();
    if (id == 1) {
        ClearUserLoginFields();
        $("#div_LoginArea").show();
        $("#div_forgotlogin").show();
        $("#txt_ForgotEmail").focus();
    }
    else if (id == 2) {
        ClearUserLoginFields();
        $("#div_LoginArea").show();
        $("#div_login").show();
        $("#txt_userName").focus();
    }
    else if (id == 3) {
        ClearUserLoginFields();
        $("#div_message").show();
        $("#txt_userName").focus();
    }
}

function ClearUserLoginFields() {
    if (!$("#chk_rememberme").is(":checked")) {
        $("#txt_userName").val("");
        $("#txt_Password").val("");
    }
    $("#txt_ForgotEmail").val("");
    $("#txt_userName").css("background", "#FFFFFF");
    $("#txt_Password").css("background", "#FFFFFF");
    $("#txt_ForgotEmail").css("background", "#FFFFFF");
}

function HideCreateUserAccountModel() {
    $("#Modal_UserLogin").modal("show");
    $("#div_LoginArea").hide();
    $("#div_message").show();
    //ClearCreateAccount();
}

function ValidateUserRetrieve() {
    var entriesok = true;
    //---Textboxes------
    var txtbxs = ["txt_ForgotEmail"];
    if (!validateEmail(txtbxs)) {
        entriesok = false;
    }
    if (entriesok) {

        var obj = {};
        obj.Item0 = $("#txt_ForgotEmail").val();        
        $.ajax({
            type: "POST",
            url: "api/FSB/RetrievePassword",
            data: JSON.stringify(obj),
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: OnSuccessUserRetrievePassword,
            failure: function (response) {
                //alert(response.d);
            },
            error: function (response) {
                //alert(response.d);
            }
        }); return false;
    }
    else {
        return entriesok;
    }
}

function OnSuccessUserRetrievePassword(response) {   
    ShowUserLoginModelAfterLoad();
    //show_box_User(1);
    show_box_User(3);
    switch (response.rcode) {
        case "0":
            InfoPopupUser(response.rtitle, response.rmsg, '1');
            break;
        case "1":
            $("#Modal_UserLogin").modal("hide");
            SuccessPopupUser2(response.rtitle, response.rmsg);
            break;
    }
}

/*-------------User LOGIN END-------------*/

function GoToStore(url) {    
    var go_to_url = url;    
    //this will redirect us in new tab
    window.open(go_to_url, '_blank');

}


$("#txt_search").keypress(function (event) {
    var keycode = (event.keyCode ? event.keyCode : event.which);
    if (keycode == "13") {
        SearchProducts(); return false;
    }
});

function SearchProducts() {
    ProductFirstLoad();
    $("#hid_wiat").val("1");
    if ($("#hid_upperLimit").val() != "0" && $("#hid_upperLimit").val() != "" && $("#hid_scrollEnd").val() != "YES" && $("#hid_wiat").val() != "0") {
        $(".se-pre-con").show();
        $(".se-pre-con").center();
        $("#hid_wiat").val("0");
        var obj = {};
        obj.Item0 = $("#hid_showInId").val();
        obj.Item1 = $("#hid_sortVal").val();
        obj.Item2 = $("#hid_category").val();
        obj.Item3 = $("#txt_search").val();
        obj.l_Limit = $("#hid_lowerLimit").val();
        obj.u_Limit = $("#hid_upperLimit").val();
        obj.rowCount = "5";

        $.ajax({
            type: "POST",
            url: "api/FSB/LoadProducts",
            data: JSON.stringify(obj),
            contentType: "application/json; charset=utf-8",
            dataType: "JSON",
            success: OnSuccessSearchProducts,
            failure: function (response) {
                //alert(response.d);
            },
            error: function (response) {
                //alert(response.d);
            }
        });

    }
}

function OnSuccessSearchProducts(response) {
    switch (response.rcode) {
        case "0":
            InfoPopup(response.rtitle, response.rmsg);
            break;
        case "1":
            $("#hid_lowerLimit").val(response.l_Limit);
            $("#hid_upperLimit").val(response.u_Limit);
            $("#div_sortItem").show();
            $("#hid_scrollEnd").val(response.Item1)
            $("#div_products").append(response.Item0);
            $("#hid_wiat").val("1");
            setTimeout(function () {
                $(".se-pre-con").hide();
            }, 500);            
            break;
    }
}

function LoadProducts() {
    if ($("#hid_upperLimit").val() != "0" && $("#hid_upperLimit").val() != "" && $("#hid_scrollEnd").val() != "YES" && $("#hid_wiat").val() != "0") {
        
        $(".se-pre-con").show();
        $(".se-pre-con").center();
        $("#hid_wiat").val("0"); 
        var obj = {};
        obj.Item0 = $("#hid_showInId").val();        
        obj.Item1 = $("#hid_sortVal").val();
        obj.Item2 = $("#hid_category").val();
        obj.Item3 = $("#txt_search").val();
        obj.l_Limit = $("#hid_lowerLimit").val();
        obj.u_Limit = $("#hid_upperLimit").val();
        obj.rowCount = "5";

        $.ajax({
            type: "POST",
            url: "api/FSB/LoadProducts",
            data: JSON.stringify(obj),
            contentType: "application/json; charset=utf-8",
            dataType: "JSON",
            success: OnSuccessLoadProducts,
            failure: function (response) {
                //alert(response.d);
            },
            error: function (response) {
                //alert(response.d);
            }
        });
    }
}

function OnSuccessLoadProducts(response) {    
    switch (response.rcode) {
        case "0":
            InfoPopup(response.rtitle, response.rmsg);
            break;
        case "1":
            $("#hid_lowerLimit").val(response.l_Limit);
            $("#hid_upperLimit").val(response.u_Limit);
            $("#div_sortItem").show();
            $("#hid_scrollEnd").val(response.Item1)
            $("#div_products").append(response.Item0);            
            $("#hid_wiat").val("1");
            setTimeout(function () {
                $(".se-pre-con").hide();
            }, 500);            
            break;
    }
}

/*---------CATEGORY SELECT--------*/

function LoadCategory() {
    var obj = {};
    obj.Item0 = $("#hid_showInId").val();
    $.ajax({
        type: "POST",
        url: "api/FSB/LoadCategory",
        data: JSON.stringify(obj),
        contentType: "application/json; charset=utf-8",
        dataType: "JSON",
        success: OnSuccessLoadCategory,
        failure: function (response) {
            //alert(response.d);
        },
        error: function (response) {
            //alert(response.d);
        }
    });
}

function OnSuccessLoadCategory(data) {
    PopulateCategoryControl(data, $("#ddl_category"));
}

function PopulateControl(list, control) {
    if (list.length > 0) {
        control.empty();
        $.each(list, function (key, value) {
            control.append($('<option>', { value: value.ID, text: value.Name }));
        });
    }
}

function PopulateCategoryControl(list, control) {
    if (list.length > 0) {
        control.empty();
        $.each(list, function (key, value) {
            control.append($('<option>', { value: value.ID, text: value.Name }));
        });
    }    
    if (list.length > 1) {
        $(".categoryddl").show();
    }
}

$("#ddl_category").change(function () {    
    $("#hid_category").val($("#ddl_category").val());
    ProductFirstLoad();
    LoadProducts();
});
/*---------END--------*/

/*---------SORT ITEM--------*/

function ProductFirstLoad() {
    $("#hid_lowerLimit").val("0");
    $("#hid_upperLimit").val("12");
    $("#hid_scrollEnd").val("NO");
    $("#div_products").html("");
    $("#hid_category").html("0");
}

$(function () {
    $("#div_sortItem .dropdown-menu li a").click(function () {        
        var selText = $(this).html();
        //working version - for single button //
        //$('.btn:first-child').html(selText+'<span class="caret"></span>');  
        //working version - for multiple buttons //
        $(this).parents("#div_sortItem").find(".btn-sort").html(selText);
        switch (($(this).parents("#div_sortItem").find(".btn-sort").find(".label-icon").html())) {
            case "Newest products":
                $("#hid_sortVal").val("1");
                ProductFirstLoad();
                LoadProducts();               
                break;

            case "Oldest products":
                $("#hid_sortVal").val("2");
                ProductFirstLoad();
                LoadProducts();                
                break;

            case "Price: Low to High":
                $("#hid_sortVal").val("3");
                ProductFirstLoad();
                LoadProducts();                
                break;

            case "Price: High to Low":
                $("#hid_sortVal").val("4");
                ProductFirstLoad();
                LoadProducts();                
                break;

            case "Popularity (High to Low)":
                $("#hid_sortVal").val("5");
                ProductFirstLoad();
                LoadProducts();                
                break;

            case "Popularity (Low to High)":
                $("#hid_sortVal").val("6");
                ProductFirstLoad();
                LoadProducts();                
                break;

            default:
                $("#hid_sortVal").val("1");
                ProductFirstLoad();
                LoadProducts();                
                break;
        }
        $(document).ajaxComplete(function () {
            setTimeout(function () {
                $(".a_loadposition").focus();
            }, 500);        
        });
        
    });
});

//-------------------------------------------------

/*------------------------------PRODUCTS PAGE----------------*/

jQuery.fn.center = function () {
    this.css("position", "fixed");
    this.css("top", ($(window).height() / 2) - (this.outerHeight() / 2));
    this.css("left", ($(window).width() / 2) - (this.outerWidth() / 2));
    return this;
}

$(document).ready(function () {
    //-----------MIN SCREEN HEIGHT------
    var clientHeight = document.documentElement.clientHeight;
    var clientWidth = document.documentElement.clientWidth;
    if (clientWidth < 760) {
        clientHeight = clientHeight - 200;
        $('#wrapper1').css('min-height', clientHeight + 'px');
    }
    else {
        clientHeight = clientHeight - 220;
        $('#wrapper1').css('min-height', clientHeight + 'px');
    }
    //----------------------------------   

    //------------SCROLE TOP------------------
    $(window).scroll(function () {
        if ($(this).scrollTop() > 100) {
            $('.scrollup').fadeIn();

        } else {
            $('.scrollup').fadeOut();
        }

    });
    $('.scrollup').click(function () {
        $("html, body").animate({ scrollTop: 0 }, 600);
        return false;
    });

    //$(document).ajaxStart(function () {
    //    $(".se-pre-con").show();
    //    $(".se-pre-con").center();
    //});

    //$(document).ajaxComplete(function () {
    //    setTimeout(function () {
    //        $(".se-pre-con").hide();
    //    }, 500);        
    //});



    //---------FIXED TOP MENU AFTER SOME SCROLE---------
    $(window).bind("scroll", function () {
        var navHeight = $(window).height() - 300;
        if ($(window).scrollTop() > navHeight) {
            $("#menu_nonmobile").addClass("fixed");
            $("#menu_mobile").addClass("fixed");            
        }
        else {
            $("#menu_nonmobile").removeClass("fixed");
            $("#menu_mobile").removeClass("fixed");            
        }
    });
    //---------------------------------------

});