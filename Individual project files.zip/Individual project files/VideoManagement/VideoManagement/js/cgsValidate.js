var submit_click=false;
if(typeof String.prototype.trim !== 'function') {
  String.prototype.trim = function() {
    return this.replace(/^\s+|\s+$/g, ''); 
  }
}
        function Init (frm) {
            var form = document.getElementById (frm);
            if ("onfocusin" in form) {  // Internet Explorer
                    // the attachEvent method can also be used in IE9,
                    // but we want to use the cross-browser addEventListener method if possible
                if (form.addEventListener) {    // IE from version 9
                    form.addEventListener ("focusout", automaticCall, false);
                }
                else {
                    if (form.attachEvent) {     // IE before version 9
                        form.attachEvent ("onfocusout", automaticCall);
                    }
                }
            }
            else {
                if (form.addEventListener) {    // Firefox, Opera, Google Chrome and Safari
                        // since Firefox does not support the DOMFocusIn/Out events
                        // and we do not want browser detection
                        // the focus and blur events are used in all browsers excluding IE
                        // capturing listeners, because focus and blur events do not bubble up
                    form.addEventListener ("blur", automaticCall, true);
                }
            }
        }
function automaticCall()
{
    if(submit_click)
    {
        validateEntries();
    }
}
function validateTxtBxs(txtbxs)
{

	var allok=true;
	for(i=0;i<txtbxs.length;i++)
	{
		if((document.getElementById(txtbxs[i]).value==null) || (document.getElementById(txtbxs[i]).value.trim()==""))
		{
			document.getElementById(txtbxs[i]).style.backgroundColor="#FFCCCC";
			allok=false;
		}
		else
		{
			document.getElementById(txtbxs[i]).style.backgroundColor="white";
		}
	}
	return allok;
}

function validateDateFiled(txtbxs) {//yyyy-mm-dd

    var allok = true;
    var rgx = /(\d{4})-(\d{2})-(\d{2})/;
    for (i = 0; i < txtbxs.length; i++) {        
        var s = document.getElementById(txtbxs[i]).value;
        if (!s.match(rgx)) {
            document.getElementById(txtbxs[i]).value = "";
            document.getElementById(txtbxs[i]).style.backgroundColor = "#FFCCCC";
            allok = false;
        }
        else {
            document.getElementById(txtbxs[i]).style.backgroundColor = "white";
        }
    }
    return allok;
}

function validateDDLs(ddls,uaindex)
{
	var allok=true;
	for(i=0;i<ddls.length;i++)
	{
		if(document.getElementById(ddls[i]).selectedIndex == uaindex)
		{
			document.getElementById(ddls[i]).style.backgroundColor="#FFCCCC";
			allok=false;
		}
		else
		{
			document.getElementById(ddls[i]).style.backgroundColor="white";
		}
	}
	return allok;
}
function validateRadioButtonList(rblName, rblId) {
    var listItemArray = document.getElementsByName(rblName);
    var isItemChecked = false;
    for (var i = 0; i < listItemArray.length; i++) {
        var listItem = document.getElementById(rblId + "_" + i);
        if(listItem!=null)
        {
			if (listItem.checked) {
				isItemChecked = true;
			}
        }
    }
    if(isItemChecked)
    {
		document.getElementById(rblId).style.backgroundColor="white";
    }
    else
    {
		document.getElementById(rblId).style.backgroundColor="#FFCCCC";
    }
    return isItemChecked;
}
function validateEmail(txtbxs)
{
	var allok=true;
	var x;
    var atpos;
    var dotpos;
	for(i=0;i<txtbxs.length;i++)
	{
	    x = document.getElementById(txtbxs[i]).value.trim();
        atpos=x.indexOf("@");
        dotpos=x.lastIndexOf(".");
        if (atpos<1 || dotpos<atpos+2 || dotpos+2>=x.length)
        {
            document.getElementById(txtbxs[i]).style.backgroundColor="#FFCCCC";
			allok=false;
        }
        else
		{
			document.getElementById(txtbxs[i]).style.backgroundColor="white";
		}
	}
	return allok;
}

function validateEmailIgnoreBlank(txtbxs) {   
    var allok = true;
    var x;
    var atpos;
    var dotpos;
    for (i = 0; i < txtbxs.length; i++) {
        x = document.getElementById(txtbxs[i]).value.trim();
        document.getElementById(txtbxs[i]).style.backgroundColor = "white";
        if (x.trim() != "") {

            atpos = x.indexOf("@");
            dotpos = x.lastIndexOf(".");
            if (atpos < 1 || dotpos < atpos + 2 || dotpos + 2 >= x.length) {
                document.getElementById(txtbxs[i]).style.backgroundColor = "#FFCCCC";
                allok = false;
            }           
        }
    }
    return allok;
}

/*--------------------------- By Aromal------------------------------------------ */
function validateConfirmFields(field1, field2) {
    var allok = true;
    if (document.getElementById(field1).value.trim() != document.getElementById(field2).value.trim()) {
        document.getElementById(field2).style.backgroundColor = "#FFCCCC";
        allok = false;
    } else {
        document.getElementById(field2).style.backgroundColor = "white";
    }
    return allok;
}

function _ValidateSelect(multiselectid) {
    var $values = $glue = '';
    var allok = false;
    for (var $i = 0; $i < document.getElementById(multiselectid).length; $i++) {
        if (document.getElementById(multiselectid)[$i].selected == true) {
            $values += $glue + document.getElementById(multiselectid)[$i].value;
            $glue = ', ';
        }
    }
    if ($values != '') {
        // alert($values);
        allok = true;
        //document.getElementById(multiselectid).style.backgroundColor = "white";
    }
    else {
        //alert('Please Select any member');
        //document.getElementById(multiselectid).style.backgroundColor = "#FFCCCC";
        allok = false;
    }
    return allok;
}


function ValidateImagUpload(FileUpload) {

    var allok = true;
    debugger;

    var array = ['jpg', 'jpeg', 'bmp', 'gif', 'png'];
    
    var uploader = document.getElementById(FileUpload);
    var Extension = uploader.value.trim().substring(uploader.value.lastIndexOf('.') + 1).toLowerCase();
    if (Extension != null && Extension.trim() != "") {
        if (array.indexOf(Extension) <= -1) {
            document.getElementById(FileUpload).style.backgroundColor = "#FFCCCC";
            allok = false;
        }
        else {
            document.getElementById(FileUpload).style.backgroundColor = "white";
        }
    }
    else {
        document.getElementById(FileUpload).style.backgroundColor = "white";
    }
    return allok;

}

/*--------------------------- End---------------------------------------------- */

function validateCanadaZipCode(txtbxs)
{
	var allok=true;
	var re = /^([A-Za-z]\d[A-Za-z] \d[A-Za-z]\d|[A-Za-z]\d[A-Za-z]\d[A-Za-z]\d)$/;
	for(i=0;i<txtbxs.length;i++)
	{
		if(!re.test(document.getElementById(txtbxs[i]).value))
        {
            document.getElementById(txtbxs[i]).style.backgroundColor="#FFCCCC";
			allok=false;
        }
        else
		{
			document.getElementById(txtbxs[i]).style.backgroundColor="white";
		}
	}
	return allok;
}
function validateUSZipCode(txtbxs)
{
	var allok=true;
	var re = /^(\d{5}-\d{4}|\d{5})$/;
	for(i=0;i<txtbxs.length;i++)
	{
		if(!re.test(document.getElementById(txtbxs[i]).value))
        {
            document.getElementById(txtbxs[i]).style.backgroundColor="#FFCCCC";
			allok=false;
        }
        else
		{
			document.getElementById(txtbxs[i]).style.backgroundColor="white";
		}
	}
	return allok;
}
function validatePhone(txtbxs)
{
	var allok=true;
	var re = /^[\(]?\d{3}[\s\)-]?\d{3}[\s-]?\d{4}$/;
	for(i=0;i<txtbxs.length;i++)
	{
		if(!re.test(document.getElementById(txtbxs[i]).value))
        {
            document.getElementById(txtbxs[i]).style.backgroundColor="#FFCCCC";
			allok=false;
        }
        else
		{
			document.getElementById(txtbxs[i]).style.backgroundColor="white";
		}
	}
	return allok;
}

//Check Number 
function isNumberKey(evt) {
    var charCode = (evt.which) ? evt.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57))
        return false;

    return true;
}
//Check decimel Number / price
function isPriceKey(txtVal, evt) {  

    var charCode = (evt.which) ? evt.which : event.keyCode;
    if (evt.shiftKey == true) {
        alert("shift");
        return false;
    }
    if ((charCode >= 48 && charCode <= 57) ||
            (charCode >= 96 && charCode <= 105) ||
            charCode == 8 || charCode == 9 || charCode == 37 ||
            charCode == 39 || charCode == 46 || charCode == 190) {

    } else {
        return false;
    }
    if (txtVal.indexOf('.') == -1) {
        if (charCode != 46) {
            if (charCode > 31 && (charCode < 48 || charCode > 57))
                return false;
        }
    }
    else {
        if (charCode > 31 && (charCode < 48 || charCode > 57))
            return false;
    }
    return true;
}



function IsAlphaNumeric(e) {
    var specialKeys = new Array();
    specialKeys.push(8); //Backspace
    specialKeys.push(9); //Tab
    specialKeys.push(46); //Delete
    specialKeys.push(36); //Home
    specialKeys.push(35); //End
    specialKeys.push(37); //Left
    specialKeys.push(39); //Right
    var keyCode = e.keyCode == 0 ? e.charCode : e.keyCode;
    var ret = ((keyCode >= 48 && keyCode <= 57) || (keyCode >= 65 && keyCode <= 90) || (keyCode >= 97 && keyCode <= 122) || (specialKeys.indexOf(e.keyCode) != -1 && e.charCode != e.keyCode));
    //document.getElementById("error").style.display = ret ? "none" : "inline";
     return ret;
}

function isValidCreditCard(type, ccnum) {
    ccnum = ccnum.replace(" ").join("");
    if (type == "Visa") {
        // Visa: length 16, prefix 4, dashes optional.
        var re = /^4\d{3}-?\d{4}-?\d{4}-?\d{4}$/;
    } else if (type == "MC") {
        // Mastercard: length 16, prefix 51-55, dashes optional.
        var re = /^5[1-5]\d{2}-?\d{4}-?\d{4}-?\d{4}$/;
    } else if (type == "AmEx") {
        // American Express: length 15, prefix 34 or 37.
        var re = /^3[4,7]\d{13}$/;
    }
    if (!re.test(ccnum)) return false;
    // Remove all dashes for the checksum checks to eliminate negative numbers
    ccnum = ccnum.split("-").join("");
    // Checksum ("Mod 10")
    // Add even digits in even length strings or odd digits in odd length strings.
    var checksum = 0;
    for (var i = (2 - (ccnum.length % 2)) ; i <= ccnum.length; i += 2) {
        checksum += parseInt(ccnum.charAt(i - 1));
    }
    // Analyze odd digits in even length strings or even digits in odd length strings.
    for (var i = (ccnum.length % 2) + 1; i < ccnum.length; i += 2) {
        var digit = parseInt(ccnum.charAt(i - 1)) * 2;
        if (digit < 10) { checksum += digit; } else { checksum += (digit - 9); }
    }
    if ((checksum % 10) == 0) return true; else return false;
}

function getRadiobuttonSelectedItem(rblName, rblId) {   
    var listItemArray = document.getElementsByName(rblName);
    var isItemChecked = false;
    for (var i = 0; i < listItemArray.length; i++) {
        var listItem = document.getElementById(rblId + "_" + i);
        if (listItem != null) {
            if (listItem.checked) {
                isItemChecked = true;
                return listItem.id;
                break;

            }
        }
    }
}


/*------------Popup messages---------*/
function InfoPopup(title, msg) {
    if (title == "")
        title = "Warning";
    swal({
        title: title,
        text: msg,
        html: true,
        type: "warning"
    });

    $(".confirm").click(function () {
        if ($(".modal-backdrop").length > 1)
            $(".modal-backdrop").last().remove();
        $("body").removeAttr("style");
if(title == "Session expired"){    
    $(location).attr("href", "logout");
}
    });
    return false;
}

function SuccessPopup(title, msg) {
    if (title == "")
        title = "Success";
    swal({
        title: title,
        text: msg,
        html: true,
        type: "success"
    });

    $(".confirm").click(function () {
        if ($(".modal-backdrop").length > 1)
            $(".modal-backdrop").last().remove();
        $("body").removeAttr("style");
    });
    return false;
}

function SuccessPopupWithRedirection(title, msg, url) {
    if (title == "")
        title = "Success";
    swal({
        title: title,
        text: msg,
        html: true,
        type: "success"
    });

    $(".confirm").click(function () {
        $(location).attr("href", url);
    });
    return false;
}

function SuccessPopupWithReload(title, msg) {
    if (title == "")
        title = "Success";
    swal({
        title: title,
        text: msg,
        html: true,
        type: "success"
    });

    $(".confirm").click(function () {
        location.reload();
    });
    return false;
}


function ErrorPopup(title, msg) {
    if (title == "")
        title = "Warning";
    swal({
        title: title,
        text: msg,
        html: true,
        type: "error"
    });
    $(".confirm").click(function () {
        if ($(".modal-backdrop").length > 1)
            $(".modal-backdrop").last().remove();
        $("body").removeAttr("style");
    });
    return false;
}

//function validateUrl(textval)   // return true or false.
//{
//    var urlregex = new RegExp(
//          "^(http:\/\/www.|https:\/\/www.|ftp:\/\/www.|www.){1}([0-9A-Za-z]+\.)");
//    return urlregex.test(textval);
//}

function validateUrl(txtbxs) {
    var allok = true;
    //var re = /^((https?|ftp|smtp):\/\/)?(www.)?[a-z0-9]+(\.[a-z]{2,}){1,3}(#?\/?[a-zA-Z0-9#]+)*\/?(\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$/;
    var re = /(https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|www\.[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9]+\.[^\s]{2,}|www\.[a-zA-Z0-9]+\.[^\s]{2,})/gi;
    for (i = 0; i < txtbxs.length; i++) {
        if (!re.test(document.getElementById(txtbxs[i]).value)) {
            document.getElementById(txtbxs[i]).style.backgroundColor = "#FFCCCC";
            allok = false;
        }
        else {
            document.getElementById(txtbxs[i]).style.backgroundColor = "white";
        }
    }
    return allok;
}




function ValidateDatePicker(txtbxs) {//yyyy-mm-dd
    var allok = true;
    var rgx = /(\d{4})-(\d{2})-(\d{2})/;
    for (i = 0; i < txtbxs.length; i++) {
        var s = document.getElementById(txtbxs[i]).value;        
        if (!isDate(s)) {
            document.getElementById(txtbxs[i]).value = "";
            document.getElementById(txtbxs[i]).style.backgroundColor = "#FFCCCC";
            allok = false;
        }
        else {
            document.getElementById(txtbxs[i]).style.backgroundColor = "white";
        }
    }
    return allok;
}

function isDate(txtDate) {
    var currVal = txtDate;
    if (currVal == '')
        return false;
    //Declare Regex 
    var rxDatePattern = /^(\d{4})(\/|-)(\d{1,2})(\/|-)(\d{1,2})$/;
    var dtArray = currVal.match(rxDatePattern); // is format OK?
    if (dtArray == null)
        return false;

    //Checks for mm/dd/yyyy format.
    //dtMonth = dtArray[1];
    //dtDay = dtArray[3];
    //dtYear = dtArray[5];

    //Checks for dd/mm/yyyy format.
    dtYear = dtArray[1];
    dtMonth = dtArray[3];
    dtDay = dtArray[5];

    if (dtMonth < 1 || dtMonth > 12)
        return false;
    else if (dtDay < 1 || dtDay > 31)
        return false;
    else if ((dtMonth == 4 || dtMonth == 6 || dtMonth == 9 || dtMonth == 11) && dtDay == 31)
        return false;
    else if (dtMonth == 2) {
        var isleap = (dtYear % 4 == 0 && (dtYear % 100 != 0 || dtYear % 400 == 0));
        if (dtDay > 29 || (dtDay == 29 && !isleap))
            return false;
    }
    return true;
}


jQuery.fn.center = function () {
    this.css("position", "fixed");
    this.css("top", ($(window).height() / 2) - (this.outerHeight() / 2));
    this.css("left", ($(window).width() / 2) - (this.outerWidth() / 2));
    return this;
}
///*---------------THIS IS FOR CLOSING ONE MODEL AND OPENING OTHER MODEL ISSUE FIX----------------*/
//$('.modal').on("hidden.bs.modal", function (e) {
//    if ($('.modal:visible').length) {
//        $('.modal-backdrop').first().css('z-index', parseInt($('.modal:visible').last().css('z-index')) - 10);
//        $('body').addClass('modal-open');
//    }
//}).on("show.bs.modal", function (e) {
//    if ($('.modal:visible').length) {
//        $('.modal-backdrop.in').first().css('z-index', parseInt($('.modal:visible').last().css('z-index')) + 10);
//        $(this).css('z-index', parseInt($('.modal-backdrop.in').first().css('z-index')) + 10);
//    }
//});
///*---------------END----------------------*/

function PopulateControl(list, control) {
    if (list.length > 0) {
        control.empty();
        $.each(list, function (key, value) {
            control.append($('<option>', { value: value.ID, text: value.Name }));
        });
    }
}

function ValidateColor(colorcode) {
    return /(^#[0-9A-F]{6}$)|(^#[0-9A-F]{3}$)/i.test("#" + colorcode);
}

function OpenNewWindow(url) {
    var win = window.open();
    win.location = url;
    win.opener = null;
    win.blur();
    window.focus();
}

/*--------------------Popupblocker check-------------------*/
var popupBlockerChecker = {
    check: function (popup_window) {
        var _scope = this;
        if (popup_window) {
            if (/chrome/.test(navigator.userAgent.toLowerCase())) {
                setTimeout(function () {
                    _scope._is_popup_blocked(_scope, popup_window);
                }, 200);
            } else {
                popup_window.onload = function () {
                    _scope._is_popup_blocked(_scope, popup_window);
                };
            }
        } else {
            _scope._displayError();
        }
    },
    _is_popup_blocked: function (scope, popup_window) {
        if ((popup_window.innerHeight > 0) == false) { scope._displayError(); }
    },
    _displayError: function () {
        //alert("Popup Blocker is enabled! Please add this site to your exception list.");
        $(location).attr("href", response.Item0);
        /*CREATE A LINK DYNAMICALLY
        var link = document.createElement("a");
        link.setAttribute("href", response.Item0);
        link.setAttribute("target", "_blank");
        link.setAttribute("id", "openwin");
        document.body.appendChild(link);
        link.click();*/
    }
};

function OpenNewWindowRemovePopUpBlocker(url) {
    var popup = window.open(url, '_blank');
    popupBlockerChecker.check(popup);
}

/*--------------------End Popupblocker check-------------------*/

$.ajaxSetup({
    cache: false
});