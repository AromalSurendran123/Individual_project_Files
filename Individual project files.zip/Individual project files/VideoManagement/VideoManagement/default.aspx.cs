﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace VideoManagement
{
    public partial class _default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            User usr = new User();
            hid_UserId.Value = "";
            if (Session["VDOUSR"] != null)
            {
                if (Session["VDOUSR"].ToString() != "")
                {
                    usr = (User)Session["VDOUSR"];
                    hid_UserId.Value = usr.UserId;
                    ltrl_AddVideo.Text = "<input id=\"btn_AddVideo\" type=\"button\" class=\"btn btn-primary\" "+
                        "value=\"Add Video\" onclick=\"AddVideoModal();\" style=\"height: 50px;\" />";
                }
            }
        }
    }
}