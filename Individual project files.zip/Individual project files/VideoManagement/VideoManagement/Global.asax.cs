﻿using System;
using System.Configuration;
using System.Globalization;
using System.Text.RegularExpressions;
using System.Threading;
using System.Web;
using System.Web.Http;
using System.Web.Routing;

namespace VideoManagement
{
    public class WebApiApplication : System.Web.HttpApplication
    {
        
        protected void Application_Start(object sender, EventArgs e)
        {
            GlobalConfiguration.Configure(WebApiConfig.Register);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            RegisterPageRoutes(RouteTable.Routes);
        }        

        protected void Session_Start(object sender, EventArgs e)
        {
            
        }
        
        protected void Application_BeginRequest(object sender, EventArgs e)
        {
            string PathUrl = Request.Path.ToLower().Trim();
            if (!string.IsNullOrEmpty(PathUrl) && PathUrl.IndexOf("/api/") == -1  && PathUrl.IndexOf(".asmx") == -1 && PathUrl.IndexOf(".axd") == -1)
            {
                if (PathUrl.IndexOf("default.aspx") != -1)
                    Response.Redirect("search");                               
            }
        }         

        protected void Application_AuthenticateRequest(object sender, EventArgs e)
        {

        }

        protected void Application_Error(object sender, EventArgs e)
        {

        }

        protected void Session_End(object sender, EventArgs e)
        {

        }

        protected void Application_End(object sender, EventArgs e)
        {

        }

        static void RegisterPageRoutes(RouteCollection routes)
        {
            routes.MapPageRoute("search", "search", "~/default.aspx");
            routes.MapPageRoute("logout", "logout", "~/logout.aspx");        
        }
    }
}