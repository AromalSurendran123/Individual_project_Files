﻿# Host: localhost  (Version: 5.0.9-beta-nt)
# Date: 2022-08-12 17:56:58
# Generator: MySQL-Front 5.3  (Build 2.30)

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE */;
/*!40101 SET SQL_MODE='' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES */;
/*!40103 SET SQL_NOTES='ON' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS */;
/*!40014 SET FOREIGN_KEY_CHECKS=0 */;

USE `videomanagement`;

#
# Source for table "tbl_users"
#

DROP TABLE IF EXISTS `tbl_users`;
CREATE TABLE `tbl_users` (
  `fld_Id` int(11) NOT NULL auto_increment,
  `fld_FirstName` varchar(255) default NULL,
  `fld_LastName` varchar(255) default NULL,
  `fld_Email` varchar(255) default NULL,
  `fld_Password` varchar(255) default NULL,
  `fld_Status` tinyint(3) default NULL,
  PRIMARY KEY  (`fld_Id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;

#
# Data for table "tbl_users"
#

/*!40000 ALTER TABLE `tbl_users` DISABLE KEYS */;
INSERT INTO `tbl_users` VALUES (1,'Sam','S','s@s.com','lKEtvC2qdKTHS8kTR54utQ==',1),(2,'Albert','Asdert','a@a.com','rMMEBC62v+x/3sLSx/SDtA==',1),(3,'Thomas','E','t@t.com','EIiq+VYUUZghPEQNW3lkVQ==',1);
/*!40000 ALTER TABLE `tbl_users` ENABLE KEYS */;

#
# Source for table "tbl_video_access"
#

DROP TABLE IF EXISTS `tbl_video_access`;
CREATE TABLE `tbl_video_access` (
  `fld_Id` int(11) NOT NULL auto_increment,
  `fld_UserId` int(11) default NULL,
  `fld_VideoId` int(11) default NULL,
  `fld_Status` tinyint(3) default NULL COMMENT '1 - Restricted; 0 - Non Restricted;',
  PRIMARY KEY  (`fld_Id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=FIXED;

#
# Data for table "tbl_video_access"
#

/*!40000 ALTER TABLE `tbl_video_access` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_video_access` ENABLE KEYS */;

#
# Source for table "tbl_videos"
#

DROP TABLE IF EXISTS `tbl_videos`;
CREATE TABLE `tbl_videos` (
  `fld_Id` int(11) NOT NULL auto_increment,
  `fld_Order` int(11) default NULL,
  `fld_Title` varchar(255) default NULL,
  `fld_FileName` varchar(255) default NULL,
  `fld_AccessType` tinyint(3) default NULL COMMENT '0 - Private; 1 - Public;',
  `fld_Downloadable` tinyint(3) default '0',
  `fld_AddedBy` int(11) default NULL,
  `fld_DateAdded` datetime default NULL,
  `fld_DateModified` datetime default NULL,
  `fld_Status` tinyint(3) default '1',
  PRIMARY KEY  (`fld_Id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;

#
# Data for table "tbl_videos"
#

/*!40000 ALTER TABLE `tbl_videos` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_videos` ENABLE KEYS */;

/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
